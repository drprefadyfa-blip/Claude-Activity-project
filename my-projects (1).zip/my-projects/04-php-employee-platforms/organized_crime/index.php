<?php
// موظفو المديرية: إضافة / تعديل / حذف / إرسال إلى الجهاز المركزي
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
require_login();

try {
    $pdo = db();
    $api = new CentralApi($pdo);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_check();
        $action = $_POST['action'] ?? '';

        if ($action === 'save') {
            [$errors, $data] = validate_employee($_POST);
            $id = (int)($_POST['id'] ?? 0);
            if (!$errors) {
                $dup = $pdo->prepare('SELECT id FROM employees WHERE employee_no = ? AND id <> ?');
                $dup->execute([$data['employee_no'], $id]);
                if ($dup->fetch()) $errors[] = 'الرقم الوظيفي مستخدم لموظف آخر';
            }
            if ($errors) { flash('bad', implode("\n", $errors)); redirect('index.php' . ($id ? '?edit=' . $id : '')); }

            if ($id) {
                $pdo->prepare('UPDATE employees SET employee_no=?, full_name=?, job_grade=?, job_title=?, department=?, updated_at=? WHERE id=?')
                    ->execute([$data['employee_no'], $data['full_name'], $data['job_grade'], $data['job_title'], $data['department'], now(), $id]);
                flash('ok', 'تم تعديل بيانات الموظف ' . $data['full_name']);
            } else {
                $pdo->prepare('INSERT INTO employees (employee_no, full_name, job_grade, job_title, department, origin, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)')
                    ->execute([$data['employee_no'], $data['full_name'], $data['job_grade'], $data['job_title'], $data['department'], 'local', now(), now()]);
                flash('ok', 'تمت إضافة الموظف ' . $data['full_name']);
            }
            redirect('index.php');
        }

        if ($action === 'delete') {
            $pdo->prepare('DELETE FROM employees WHERE id = ?')->execute([(int)$_POST['id']]);
            flash('ok', 'تم حذف الموظف من قاعدة بيانات المديرية فقط');
            redirect('index.php');
        }

        // ===== الإرسال إلى الجهاز المركزي عبر الـ API =====
        if ($action === 'send' || $action === 'send_all') {
            if ($action === 'send') {
                $stmt = $pdo->prepare('SELECT * FROM employees WHERE id = ?');
                $stmt->execute([(int)$_POST['id']]);
            } else {
                $stmt = $pdo->query("SELECT * FROM employees WHERE origin = 'local' ORDER BY id");
            }
            $list = $stmt->fetchAll();
            $created = $updated = 0;
            $failed = [];
            foreach ($list as $emp) {
                $res = $api->pushEmployee($emp);
                if (in_array($res['status'], [200, 201], true)) {
                    $res['action'] === 'updated' ? $updated++ : $created++;
                    $pdo->prepare('UPDATE employees SET central_id = ?, last_sent_at = ? WHERE id = ?')
                        ->execute([$res['body']['data']['id'] ?? null, now(), $emp['id']]);
                } else {
                    $failed[] = $emp['employee_no'] . ': ' . ($res['body']['error'] ?? 'HTTP ' . $res['status']);
                }
            }
            $msg = "تم الإرسال إلى الجهاز المركزي. جديد: {$created}، تم تحديثه: {$updated}";
            if ($failed) $msg .= "\nفشل:\n" . implode("\n", $failed);
            flash($failed ? 'warn' : 'ok', $msg);
            redirect('index.php');
        }
    }

    $grade = $_GET['grade'] ?? '';
    $q = trim($_GET['q'] ?? '');
    $where = []; $params = [];
    if ($q !== '') { $where[] = '(full_name LIKE ? OR employee_no LIKE ?)'; array_push($params, "%$q%", "%$q%"); }
    if ($grade !== '') { $where[] = 'job_grade = ?'; $params[] = $grade; }
    $stmt = $pdo->prepare('SELECT * FROM employees' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY id DESC');
    $stmt->execute($params);
    $employees = $stmt->fetchAll();

    $total   = (int)$pdo->query('SELECT COUNT(*) FROM employees')->fetchColumn();
    $local   = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE origin = 'local'")->fetchColumn();
    $sent    = (int)$pdo->query('SELECT COUNT(*) FROM employees WHERE last_sent_at IS NOT NULL')->fetchColumn();
    $fromCtr = $total - $local;

    $edit = null;
    if (isset($_GET['edit'])) {
        $s = $pdo->prepare('SELECT * FROM employees WHERE id = ?');
        $s->execute([(int)$_GET['edit']]);
        $edit = $s->fetch() ?: null;
    }
} catch (ApiException $e) {
    flash('bad', $e->getMessage());
    redirect('index.php');
} catch (Throwable $e) {
    db_error_page($e);
}

render_header('موظفو المديرية', 'index.php');
?>
<div class="stats">
  <div class="stat"><span>إجمالي الموظفين</span><b><?= $total ?></b></div>
  <div class="stat"><span>موظفو المديرية</span><b><?= $local ?></b></div>
  <div class="stat"><span>مستوردون من المركزي</span><b><?= $fromCtr ?></b></div>
  <div class="stat"><span>أُرسلوا إلى المركزي</span><b><?= $sent ?></b></div>
</div>

<div class="grid-2-1">
  <section class="card">
    <h2>قائمة الموظفين</h2>
    <form method="get" class="row">
      <div><label for="q">بحث بالاسم أو الرقم</label><input id="q" name="q" value="<?= e($q) ?>"></div>
      <div><label for="grade">الدرجة الوظيفية</label>
        <select id="grade" name="grade"><option value="">الكل</option>
          <?php foreach (JOB_GRADES as $g): ?><option <?= $g === $grade ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?>
        </select></div>
      <div style="flex:0 0 auto"><button type="submit">بحث</button></div>
    </form>
    <form method="post" class="actions"><?= csrf_field() ?><input type="hidden" name="action" value="send_all">
      <button type="submit">إرسال كل موظفي المديرية إلى الجهاز المركزي</button></form>
    <div class="tbl" style="margin-top:12px"><table>
      <thead><tr><th>الرقم الوظيفي</th><th>اسم الموظف</th><th>الدرجة الوظيفية</th><th>القسم</th><th>المصدر</th><th>آخر إرسال</th><th></th></tr></thead>
      <tbody>
      <?php if (!$employees): ?><tr><td colspan="7" class="empty">لا توجد نتائج.</td></tr><?php endif; ?>
      <?php foreach ($employees as $emp): ?>
        <tr>
          <td class="code"><?= e($emp['employee_no']) ?></td>
          <td><b><?= e($emp['full_name']) ?></b><div class="hint"><?= e($emp['job_title']) ?></div></td>
          <td><span class="pill"><?= e($emp['job_grade']) ?></span></td>
          <td><?= e($emp['department']) ?></td>
          <td><?= $emp['origin'] === 'local' ? '<span class="pill muted">المديرية</span>' : '<span class="pill ok">الجهاز المركزي</span>' ?></td>
          <td class="num hint"><?= $emp['last_sent_at'] ? e($emp['last_sent_at']) : '-' ?></td>
          <td style="white-space:nowrap">
            <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="send"><input type="hidden" name="id" value="<?= (int)$emp['id'] ?>">
              <button class="small" type="submit">إرسال</button></form>
            <a class="btn ghost small" href="?edit=<?= (int)$emp['id'] ?>">تعديل</a>
            <form method="post" onsubmit="return confirm('حذف الموظف من المديرية؟')"><?= csrf_field() ?>
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$emp['id'] ?>">
              <button class="danger small" type="submit">حذف</button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </section>

  <section class="card">
    <h2><?= $edit ? 'تعديل موظف' : 'إضافة موظف' ?></h2>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <label for="employee_no">الرقم الوظيفي</label><input id="employee_no" name="employee_no" required maxlength="30" value="<?= e($edit['employee_no'] ?? '') ?>">
      <label for="full_name">اسم الموظف</label><input id="full_name" name="full_name" required maxlength="150" value="<?= e($edit['full_name'] ?? '') ?>">
      <label for="job_grade">الدرجة الوظيفية</label>
      <select id="job_grade" name="job_grade" required>
        <?php foreach (JOB_GRADES as $g): ?><option <?= $g === ($edit['job_grade'] ?? '') ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?>
      </select>
      <label for="job_title">العنوان الوظيفي</label><input id="job_title" name="job_title" maxlength="150" value="<?= e($edit['job_title'] ?? '') ?>">
      <label for="department">القسم / الشعبة</label><input id="department" name="department" maxlength="150" value="<?= e($edit['department'] ?? '') ?>">
      <div class="actions"><button type="submit"><?= $edit ? 'حفظ التعديل' : 'إضافة' ?></button>
        <?php if ($edit): ?><a class="btn ghost" href="index.php">إلغاء</a><?php endif; ?></div>
    </form>
    <p class="hint" style="margin-top:12px">الإضافة هنا تحفظ الموظف في قاعدة بيانات المديرية. لإرساله إلى الجهاز المركزي اضغط «إرسال».</p>
  </section>
</div>
<?php render_footer();
