-- =====================================================
-- قاعدة بيانات منصة مديرية الجريمة المنظمة
-- طريقة الاستخدام: phpMyAdmin > Import > اختر هذا الملف
-- (أو افتح http://localhost/organized_crime/install.php لتنفيذه تلقائياً)
-- =====================================================

CREATE DATABASE IF NOT EXISTS crime_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE crime_db;

-- مستخدمو الواجهة (اليوزر نيم والباسورد)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- الموظفون
-- origin: local = أُضيف هنا، central = استُورد من الجهاز المركزي
CREATE TABLE IF NOT EXISTS employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_no VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  job_grade VARCHAR(50) NOT NULL,
  job_title VARCHAR(150) NULL,
  department VARCHAR(150) NULL,
  origin VARCHAR(20) NOT NULL DEFAULT 'local',
  central_id INT NULL,
  last_sent_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- سجل عمليات تناقل البيانات مع الجهاز المركزي
CREATE TABLE IF NOT EXISTS transfer_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  direction VARCHAR(10) NOT NULL,
  method VARCHAR(10) NOT NULL,
  endpoint VARCHAR(255) NOT NULL,
  status_code INT NOT NULL,
  message VARCHAR(500) NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- التوكن الحالي من الجهاز المركزي (صف واحد)
CREATE TABLE IF NOT EXISTS api_token (
  id INT PRIMARY KEY,
  token VARCHAR(128) NOT NULL,
  expires_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===== بيانات أولية للتجربة (أسماء افتراضية) =====

-- مستخدم الواجهة: admin / Admin@123
INSERT IGNORE INTO users (username, password_hash, full_name, created_at) VALUES
('admin', '$2y$10$x1P8QadKhUAbZn.LlBf6zua2Q6CVwW.J2cHt8aSxsANUT.M0gcqYO', 'مدير المنصة', NOW());

INSERT IGNORE INTO employees (employee_no, full_name, job_grade, job_title, department, origin, created_at, updated_at) VALUES
('OC-2001', 'حسين جاسم محمد', 'الدرجة الرابعة', 'محقق', 'شعبة التحقيقات', 'local', NOW(), NOW()),
('OC-2002', 'نور الهدى عادل سلمان', 'الدرجة السادسة', 'محلل معلومات', 'شعبة المعلومات', 'local', NOW(), NOW()),
('OC-2003', 'كرار فاضل عبد الله', 'الدرجة الخامسة', 'ضابط متابعة', 'شعبة المتابعة', 'local', NOW(), NOW()),
('OC-2004', 'مريم صباح هادي', 'الدرجة السابعة', 'موظف أرشيف', 'شعبة الأرشيف', 'local', NOW(), NOW());
