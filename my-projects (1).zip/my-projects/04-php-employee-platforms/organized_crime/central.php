<?php
// بيانات الجهاز المركزي: الاتصال، جلب الموظفين عبر الـ API، والاستيراد
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
require_login();

$pdo = null; $api = null;
try { $pdo = db(); $api = new CentralApi($pdo); } catch (Throwable $e) { db_error_page($e); }

$remote = null;      // نتيجة الجلب
$error = null;
$grade = $_GET['grade'] ?? '';
$search = trim($_GET['search'] ?? '');

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_check();
        $action = $_POST['action'] ?? '';

        if ($action === 'test') {
            $info = $api->info();
            if ($info['status'] !== 200) throw new ApiException('الجهاز المركزي لا يستجيب بشكل صحيح (HTTP ' . $info['status'] . ')');
            $api->clearToken();
            $api->login();
            flash('ok', 'الاتصال ناجح: ' . ($info['body']['platform'] ?? '') . "\nتم تسجيل الدخول والحصول على توكن جديد.");
        }

        if ($action === 'reset_token') {
            $api->clearToken();
            flash('ok', 'تم حذف التوكن. الطلب التالي سيسجّل الدخول تلقائياً.');
        }

        if ($action === 'import') {
            $ids = array_map('intval', $_POST['ids'] ?? []);
            $res = $api->employees(['grade' => $_POST['grade'] ?? '', 'search' => $_POST['search'] ?? '']);
            if ($res['status'] !== 200) throw new ApiException('فشل الجلب: ' . ($res['body']['error'] ?? 'HTTP ' . $res['status']));
            $rows = $res['body']['data'];
            if (($_POST['scope'] ?? '') !== 'all') $rows = array_filter($rows, fn($r) => in_array((int)$r['id'], $ids, true));
            if (!$rows) throw new ApiException('لم تختر أي موظف للاستيراد.');

            $new = $upd = 0;
            foreach ($rows as $r) {
                $find = $pdo->prepare('SELECT id FROM employees WHERE employee_no = ?');
                $find->execute([$r['employee_no']]);
                if ($localId = $find->fetchColumn()) {
                    $pdo->prepare('UPDATE employees SET full_name=?, job_grade=?, job_title=?, department=?, central_id=?, updated_at=? WHERE id=?')
                        ->execute([$r['full_name'], $r['job_grade'], $r['job_title'], $r['department'], $r['id'], now(), $localId]);
                    $upd++;
                } else {
                    $pdo->prepare('INSERT INTO employees (employee_no, full_name, job_grade, job_title, department, origin, central_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
                        ->execute([$r['employee_no'], $r['full_name'], $r['job_grade'], $r['job_title'], $r['department'], 'central', $r['id'], now(), now()]);
                    $new++;
                }
            }
            flash('ok', "تم الاستيراد من الجهاز المركزي. جديد: {$new}، تم تحديثه: {$upd}");
        }
        redirect('central.php?' . http_build_query(['grade' => $_POST['grade'] ?? $grade, 'search' => $_POST['search'] ?? $search, 'fetch' => 1]));
    }

    if (isset($_GET['fetch'])) {
        $remote = $api->employees(['grade' => $grade, 'search' => $search]);
        if ($remote['status'] !== 200) $error = 'رد الجهاز المركزي: ' . ($remote['body']['error'] ?? 'HTTP ' . $remote['status']);
    }
} catch (ApiException $e) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') { flash('bad', $e->getMessage()); redirect('central.php'); }
    $error = $e->getMessage();
}

$token = $api->tokenStatus();
$localNos = array_flip($pdo->query('SELECT employee_no FROM employees')->fetchAll(PDO::FETCH_COLUMN));

render_header('بيانات الجهاز المركزي', 'central.php');
?>
<div class="grid">
  <section class="card">
    <h2>إعدادات الربط</h2>
    <div class="tbl"><table>
      <tr><th style="width:150px">رابط الـ API</th><td class="ltr"><?= e($api->baseUrl()) ?></td></tr>
      <tr><th>API Username</th><td class="ltr"><?= e(CENTRAL_API_USERNAME) ?></td></tr>
      <tr><th>التوكن</th><td><?= $token['has_token'] ? '<span class="pill ok">صالح</span> <span class="ltr hint">' . e($token['preview']) . '</span>' : '<span class="pill bad">لا يوجد</span>' ?></td></tr>
      <tr><th>ينتهي في</th><td class="num"><?= e($token['expires_at'] ?? '-') ?></td></tr>
    </table></div>
    <div class="actions">
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="test"><button type="submit">اختبار الاتصال وتسجيل الدخول</button></form>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="reset_token"><button class="ghost" type="submit">حذف التوكن</button></form>
    </div>
    <p class="hint">تُعدّل هذه الإعدادات من ملف <code>config.php</code>.</p>
  </section>

  <section class="card">
    <h2>جلب الموظفين من الجهاز المركزي</h2>
    <form method="get">
      <input type="hidden" name="fetch" value="1">
      <label for="grade">الدرجة الوظيفية</label>
      <select id="grade" name="grade"><option value="">الكل</option>
        <?php foreach (JOB_GRADES as $g): ?><option <?= $g === $grade ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?>
      </select>
      <label for="search">بحث بالاسم أو الرقم الوظيفي</label>
      <input id="search" name="search" value="<?= e($search) ?>">
      <div class="actions"><button type="submit">جلب البيانات (GET)</button></div>
    </form>
  </section>
</div>

<?php if ($error): ?><div class="alert bad"><?= nl2br(e($error)) ?></div><?php endif; ?>

<?php if ($remote && $remote['status'] === 200): $rows = $remote['body']['data']; ?>
<section class="card">
  <h2>نتيجة الجلب: <?= (int)$remote['body']['count'] ?> موظف</h2>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="action" value="import">
    <input type="hidden" name="grade" value="<?= e($grade) ?>"><input type="hidden" name="search" value="<?= e($search) ?>">
    <div class="tbl"><table>
      <thead><tr><th><input type="checkbox" id="all" aria-label="تحديد الكل" style="width:auto"></th><th>المعرّف</th><th>الرقم الوظيفي</th><th>اسم الموظف</th><th>الدرجة الوظيفية</th><th>القسم</th><th>المصدر</th><th>في المديرية؟</th></tr></thead>
      <tbody>
      <?php if (!$rows): ?><tr><td colspan="8" class="empty">لا توجد نتائج.</td></tr><?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><input type="checkbox" name="ids[]" value="<?= (int)$r['id'] ?>" style="width:auto" aria-label="تحديد"></td>
          <td class="num"><?= (int)$r['id'] ?></td>
          <td class="code"><?= e($r['employee_no']) ?></td>
          <td><b><?= e($r['full_name']) ?></b><div class="hint"><?= e($r['job_title']) ?></div></td>
          <td><span class="pill"><?= e($r['job_grade']) ?></span></td>
          <td><?= e($r['department']) ?></td>
          <td class="ltr hint"><?= e($r['source_platform']) ?></td>
          <td><?= isset($localNos[$r['employee_no']]) ? '<span class="pill ok">موجود</span>' : '<span class="pill muted">غير موجود</span>' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <div class="actions">
      <button type="submit" name="scope" value="selected">استيراد المحدد</button>
      <button type="submit" name="scope" value="all" class="ghost">استيراد الكل</button>
    </div>
  </form>
</section>
<details class="card"><summary>الرد الخام من الـ API (JSON)</summary>
  <pre class="out"><?= e(json_encode($remote['body'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) ?></pre></details>
<script>
document.getElementById('all').onchange = e => document.querySelectorAll('input[name="ids[]"]').forEach(c => c.checked = e.target.checked);
</script>
<?php endif; ?>
<?php render_footer();
