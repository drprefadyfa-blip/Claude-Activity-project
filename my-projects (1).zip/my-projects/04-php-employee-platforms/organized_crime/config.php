<?php
// =====================================================
// إعدادات منصة مديرية الجريمة المنظمة
// =====================================================
if (file_exists(__DIR__ . '/config.local.php')) require __DIR__ . '/config.local.php';

defined('APP_NAME') || define('APP_NAME', 'مديرية الجريمة المنظمة');
defined('APP_CODE') || define('APP_CODE', 'crime');
defined('APP_MARK') || define('APP_MARK', 'ج');   // حرف الشعار

// قاعدة البيانات المحلية (إعدادات XAMPP الافتراضية)
defined('DB_HOST')  || define('DB_HOST', '127.0.0.1');
defined('DB_PORT')  || define('DB_PORT', 3306);
defined('DB_NAME')  || define('DB_NAME', 'crime_db');
defined('DB_USER')  || define('DB_USER', 'root');
defined('DB_PASS')  || define('DB_PASS', '');

// ===== بيانات الربط مع الجهاز المركزي =====
// الرابط: نفس الجهاز = localhost، أو IP جهاز الجهاز المركزي في الشبكة، مثل http://192.168.1.10/central/api
defined('CENTRAL_API_URL')      || define('CENTRAL_API_URL', 'http://localhost/central/api');
defined('CENTRAL_API_USERNAME') || define('CENTRAL_API_USERNAME', 'crime_api');
defined('CENTRAL_API_PASSWORD') || define('CENTRAL_API_PASSWORD', 'Crime@2026');
defined('CENTRAL_API_TIMEOUT')  || define('CENTRAL_API_TIMEOUT', 15); // ثانية

date_default_timezone_set('Asia/Baghdad');
