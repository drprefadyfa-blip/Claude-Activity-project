<?php
// =====================================================
// الـ API Client: الاتصال بالجهاز المركزي
// - يسجّل الدخول باسم المستخدم وكلمة المرور ويحفظ التوكن في قاعدة البيانات
// - يستخدم التوكن المحفوظ حتى قبل انتهائه بـ 30 ثانية
// - عند رد 401 يسجّل الدخول من جديد ويعيد الطلب مرة واحدة
// - يسجّل كل عملية في جدول transfer_log
// =====================================================

class ApiException extends RuntimeException {}

class CentralApi
{
    private PDO $pdo;
    private string $base;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
        $this->base = rtrim(CENTRAL_API_URL, '/');
    }

    public function baseUrl(): string { return $this->base; }

    // ---------- التوكن ----------
    public function tokenStatus(): array
    {
        $row = $this->pdo->query('SELECT * FROM api_token WHERE id = 1')->fetch();
        if (!$row || $row['expires_at'] <= now()) return ['has_token' => false, 'expires_at' => null, 'preview' => null];
        return ['has_token' => true, 'expires_at' => $row['expires_at'], 'preview' => substr($row['token'], 0, 10) . '…' . substr($row['token'], -6)];
    }

    public function clearToken(): void
    {
        $this->pdo->exec('DELETE FROM api_token');
    }

    private function token(): string
    {
        $stmt = $this->pdo->prepare('SELECT token FROM api_token WHERE id = 1 AND expires_at > ?');
        $stmt->execute([date('Y-m-d H:i:s', time() + 30)]);
        $token = $stmt->fetchColumn();
        return $token ?: $this->login();
    }

    public function login(): string
    {
        $res = $this->http('POST', 'login.php', [], ['username' => CENTRAL_API_USERNAME, 'password' => CENTRAL_API_PASSWORD], null);
        $this->log('auth', 'POST', 'login.php', $res['status'], $res['body']['error'] ?? 'تم الحصول على توكن جديد');
        if ($res['status'] !== 200 || empty($res['body']['token'])) {
            throw new ApiException('فشل تسجيل الدخول في الجهاز المركزي: ' . ($res['body']['error'] ?? ('HTTP ' . $res['status'])));
        }
        $expires = date('Y-m-d H:i:s', time() + (int)($res['body']['expires_in'] ?? 3600));
        $this->clearToken();
        $this->pdo->prepare('INSERT INTO api_token (id, token, expires_at) VALUES (1, ?, ?)')->execute([$res['body']['token'], $expires]);
        return $res['body']['token'];
    }

    // ---------- طلب عام مع التوكن ----------
    public function request(string $method, string $path, array $query = [], ?array $body = null, bool $retry = true): array
    {
        $res = $this->http($method, $path, $query, $body, $this->token());
        if ($res['status'] === 401 && $retry) {
            $this->clearToken();
            return $this->request($method, $path, $query, $body, false);
        }
        $direction = $method === 'GET' ? 'receive' : 'send';
        $msg = $res['body']['message'] ?? $res['body']['error'] ?? (isset($res['body']['count']) ? 'تم استلام ' . $res['body']['count'] . ' سجل' : '');
        $this->log($direction, $method, $path . ($query ? '?' . http_build_query($query) : ''), $res['status'], $msg);
        return $res;
    }

    // ---------- عمليات جاهزة ----------
    public function info(): array
    {
        $res = $this->http('GET', 'info.php', [], null, null);
        $this->log('receive', 'GET', 'info.php', $res['status'], $res['status'] === 200 ? 'الاتصال ناجح' : 'فشل الاتصال');
        return $res;
    }

    public function employees(array $filters = []): array
    {
        return $this->request('GET', 'employees.php', array_filter($filters, fn($v) => $v !== '' && $v !== null));
    }

    // إرسال موظف: إضافة، وإذا كان موجوداً (409) يتم تعديله
    public function pushEmployee(array $emp): array
    {
        $payload = [
            'employee_no' => $emp['employee_no'], 'full_name' => $emp['full_name'], 'job_grade' => $emp['job_grade'],
            'job_title' => $emp['job_title'], 'department' => $emp['department'],
        ];
        $res = $this->request('POST', 'employees.php', [], $payload);
        if ($res['status'] === 409 && !empty($res['body']['existing_id'])) {
            $res = $this->request('PUT', 'employees.php', ['id' => (int)$res['body']['existing_id']], $payload);
            $res['action'] = 'updated';
        } else {
            $res['action'] = 'created';
        }
        return $res;
    }

    // ---------- HTTP (cURL، وإن لم يتوفر file_get_contents) ----------
    private function http(string $method, string $path, array $query, ?array $body, ?string $token): array
    {
        $url = $this->base . '/' . ltrim($path, '/') . ($query ? '?' . http_build_query($query) : '');
        $headers = ['Accept: application/json', 'Content-Type: application/json; charset=utf-8'];
        if ($token) $headers[] = 'Authorization: Bearer ' . $token;
        $payload = $body !== null ? json_encode($body, JSON_UNESCAPED_UNICODE) : null;

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_CUSTOMREQUEST  => $method,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER     => $headers,
                CURLOPT_TIMEOUT        => CENTRAL_API_TIMEOUT,
                CURLOPT_CONNECTTIMEOUT => 5,
            ]);
            if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            $raw = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err = curl_error($ch);
            curl_close($ch);
            if ($raw === false) $this->fail($method, $path, $err);
        } else {
            $ctx = stream_context_create(['http' => [
                'method' => $method, 'header' => implode("\r\n", $headers), 'content' => $payload ?? '',
                'timeout' => CENTRAL_API_TIMEOUT, 'ignore_errors' => true,
            ]]);
            $raw = @file_get_contents($url, false, $ctx);
            if ($raw === false) $this->fail($method, $path, error_get_last()['message'] ?? 'connection failed');
            $status = 0;
            foreach ($http_response_header ?? [] as $h) if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) $status = (int)$m[1];
        }

        $decoded = json_decode((string)$raw, true);
        return ['status' => $status, 'body' => is_array($decoded) ? $decoded : ['error' => 'رد غير متوقع من الخادم', 'raw' => mb_substr((string)$raw, 0, 300)]];
    }

    private function fail(string $method, string $path, string $err): void
    {
        $this->log($method === 'GET' ? 'receive' : 'send', $method, $path, 0, 'تعذر الاتصال: ' . $err);
        throw new ApiException("تعذر الاتصال بالجهاز المركزي على {$this->base}. تأكد أن منصة الجهاز المركزي تعمل وأن الرابط صحيح في config.php.\n($err)");
    }

    private function log(string $direction, string $method, string $endpoint, int $status, ?string $message): void
    {
        try {
            $this->pdo->prepare('INSERT INTO transfer_log (direction, method, endpoint, status_code, message, created_at) VALUES (?,?,?,?,?,?)')
                ->execute([$direction, $method, mb_substr($endpoint, 0, 255), $status, mb_substr((string)$message, 0, 500), now()]);
        } catch (Throwable $e) { /* السجل اختياري */ }
    }
}
