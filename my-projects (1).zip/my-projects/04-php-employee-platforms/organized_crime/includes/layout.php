<?php
// رأس الصفحة وتذييلها

function render_header(string $title, string $active = ''): void
{
    $user = current_user();
    $nav = [
        'index.php'        => 'موظفو المديرية',
        'central.php'      => 'بيانات الجهاز المركزي',
        'transfer_log.php' => 'سجل التناقل',
    ];
    ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="platform-<?= e(APP_CODE) ?>">
<header class="topbar">
  <div class="brand">
    <span class="mark" aria-hidden="true"><?= e(APP_MARK) ?></span>
    <div><b><?= e(APP_NAME) ?></b><small>منصة بيانات الموظفين</small></div>
  </div>
  <?php if ($user): ?>
  <nav>
    <?php foreach ($nav as $href => $label): ?>
      <a href="<?= $href ?>" class="<?= $active === $href ? 'active' : '' ?>"><?= e($label) ?></a>
    <?php endforeach; ?>
  </nav>
  <div class="user"><?= e($user['full_name']) ?> · <a href="logout.php">خروج</a></div>
  <?php endif; ?>
</header>
<main class="wrap">
<?php
    $f = flash();
    if ($f) echo '<div class="alert ' . e($f['type']) . '">' . nl2br(e($f['message'])) . '</div>';
}

function render_footer(): void
{
    echo '</main><footer class="foot">' . e(APP_NAME) . ' · مثال تعليمي لتناقل البيانات عبر الـ API (PHP + MySQL)</footer></body></html>';
}
