<?php
// سجل عمليات تناقل البيانات مع الجهاز المركزي
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
require_login();

try {
    $logs = db()->query('SELECT * FROM transfer_log ORDER BY id DESC LIMIT 200')->fetchAll();
} catch (Throwable $e) {
    db_error_page($e);
}
$dirLabel = ['send' => ['إرسال', ''], 'receive' => ['استلام', 'ok'], 'auth' => ['دخول', 'muted']];

render_header('سجل التناقل', 'transfer_log.php');
?>
<section class="card">
  <h2>آخر 200 عملية مع الجهاز المركزي</h2>
  <div class="tbl"><table>
    <thead><tr><th>الوقت</th><th>الاتجاه</th><th>الطلب</th><th>المسار</th><th>النتيجة</th><th>التفاصيل</th></tr></thead>
    <tbody>
    <?php if (!$logs): ?><tr><td colspan="6" class="empty">لا توجد عمليات بعد. جرّب «بيانات الجهاز المركزي».</td></tr><?php endif; ?>
    <?php foreach ($logs as $l): [$label, $cls] = $dirLabel[$l['direction']] ?? [$l['direction'], 'muted']; ?>
      <tr>
        <td class="num"><?= e($l['created_at']) ?></td>
        <td><span class="pill <?= $cls ?>"><?= e($label) ?></span></td>
        <td><span class="method m-<?= strtolower(e($l['method'])) ?>"><?= e($l['method']) ?></span></td>
        <td class="ltr"><?= e($l['endpoint']) ?></td>
        <td><span class="pill <?= ($l['status_code'] >= 200 && $l['status_code'] < 300) ? 'ok' : 'bad' ?>"><?= (int)$l['status_code'] ?: 'فشل' ?></span></td>
        <td><?= e($l['message']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</section>
<?php render_footer();
