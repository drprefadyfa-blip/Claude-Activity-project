<?php
// توثيق الـ API مع أداة تجربة مباشرة
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
require_login();

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$base = $scheme . '://' . $_SERVER['HTTP_HOST'] . rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') . '/api';

render_header('توثيق وتجربة الـ API', 'api_docs.php');
?>
<section class="card">
  <h2>معلومات الربط</h2>
  <div class="tbl"><table>
    <tr><th style="width:220px">Base URL</th><td class="ltr"><?= e($base) ?></td></tr>
    <tr><th>طريقة المصادقة</th><td>اسم مستخدم وكلمة مرور ← توكن <code>Bearer</code> صالح <?= TOKEN_TTL ?> ثانية</td></tr>
    <tr><th>حساب التجربة</th><td><code>crime_api</code> / <code>Crime@2026</code> (مديرية الجريمة المنظمة)</td></tr>
    <tr><th>صيغة البيانات</th><td><code>Content-Type: application/json; charset=utf-8</code></td></tr>
    <tr><th>ترويسة التوكن</th><td><code>Authorization: Bearer &lt;token&gt;</code> (أو <code>X-API-Token: &lt;token&gt;</code>)</td></tr>
  </table></div>
</section>

<div class="grid">
<section class="card">
  <h2>المسارات (Endpoints)</h2>

  <div class="endpoint"><span class="method m-get">GET</span> <code>/info.php</code> <span class="pill muted">بدون توكن</span>
    <p class="hint">فحص الاتصال، وقائمة المسارات والدرجات الوظيفية المسموحة.</p></div>

  <div class="endpoint"><span class="method m-post">POST</span> <code>/login.php</code> <span class="pill muted">بدون توكن</span>
<pre>{ "username": "crime_api", "password": "Crime@2026" }</pre>
<pre>{ "success": true, "token": "9f2c...", "token_type": "Bearer",
  "expires_in": 3600, "expires_at": "2026-10-06 15:00:00" }</pre></div>

  <div class="endpoint"><span class="method m-get">GET</span> <code>/employees.php</code>
    <p class="hint">الفلترة اختيارية: <code>?grade=الدرجة الثالثة</code> و<code>&amp;department=...</code> و<code>&amp;search=...</code></p>
<pre>{ "success": true, "count": 5, "data": [ { "id": 1, "employee_no": "C-1001",
  "full_name": "أحمد كاظم جواد", "job_grade": "الدرجة الثالثة", ... } ] }</pre></div>

  <div class="endpoint"><span class="method m-get">GET</span> <code>/employees.php?id=1</code> أو <code>?employee_no=C-1001</code></div>

  <div class="endpoint"><span class="method m-post">POST</span> <code>/employees.php</code>
<pre>{ "employee_no": "OC-2001", "full_name": "حسين جاسم محمد",
  "job_grade": "الدرجة الرابعة", "job_title": "محقق", "department": "شعبة التحقيقات" }</pre>
    <p class="hint">الحقول المطلوبة: <code>employee_no</code> و<code>full_name</code> و<code>job_grade</code>. الرد <code>201</code>، أو <code>409</code> إذا كان الرقم الوظيفي موجوداً (مع <code>existing_id</code>).</p></div>

  <div class="endpoint"><span class="method m-put">PUT</span> <code>/employees.php?id=6</code>
    <p class="hint">نفس حقول الإضافة.</p></div>

  <div class="endpoint"><span class="method m-delete">DELETE</span> <code>/employees.php?id=6</code></div>

  <h3>رموز الردود</h3>
  <div class="tbl"><table>
    <tr><th>200 / 201</th><td>نجاح / تمت الإضافة</td></tr>
    <tr><th>400</th><td>صيغة الطلب خاطئة أو حقول ناقصة في تسجيل الدخول</td></tr>
    <tr><th>401</th><td>التوكن مفقود أو غير صالح أو منتهٍ، أو بيانات دخول خاطئة</td></tr>
    <tr><th>403</th><td>حساب الجهة موقوف</td></tr>
    <tr><th>404</th><td>الموظف غير موجود</td></tr>
    <tr><th>405</th><td>نوع الطلب غير مدعوم</td></tr>
    <tr><th>409</th><td>الرقم الوظيفي موجود مسبقاً</td></tr>
    <tr><th>422</th><td>بيانات الموظف غير صحيحة (مع <code>details</code>)</td></tr>
  </table></div>
</section>

<section class="card">
  <h2>تجربة مباشرة</h2>
  <label for="t_user">API Username</label><input id="t_user" class="ltr" value="crime_api">
  <label for="t_pass">API Password</label><input id="t_pass" class="ltr" value="Crime@2026">
  <div class="actions"><button type="button" id="b_login">1) تسجيل الدخول</button></div>
  <label for="t_token">التوكن</label><input id="t_token" class="ltr" placeholder="يظهر هنا بعد تسجيل الدخول">

  <h3>2) إرسال طلب</h3>
  <div class="row">
    <div style="flex:0 0 110px"><label for="t_method">الطلب</label>
      <select id="t_method"><option>GET</option><option>POST</option><option>PUT</option><option>DELETE</option></select></div>
    <div><label for="t_path">المسار</label><input id="t_path" class="ltr" value="employees.php"></div>
  </div>
  <label for="t_body">البيانات (JSON) لطلبات POST و PUT</label>
  <textarea id="t_body" class="ltr" rows="6">{
  "employee_no": "T-9001",
  "full_name": "موظف تجريبي",
  "job_grade": "الدرجة السابعة",
  "job_title": "مدقق",
  "department": "قسم التدقيق"
}</textarea>
  <div class="actions"><button type="button" id="b_send">إرسال</button></div>
  <h3>الرد</h3>
  <pre class="out" id="t_out">...</pre>
</section>
</div>

<section class="card">
  <h2>أمثلة سطر الأوامر (curl)</h2>
<pre>curl -X POST "<?= e($base) ?>/login.php" -H "Content-Type: application/json" -d "{\"username\":\"crime_api\",\"password\":\"Crime@2026\"}"

curl "<?= e($base) ?>/employees.php" -H "Authorization: Bearer TOKEN"

curl -X POST "<?= e($base) ?>/employees.php" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"employee_no\":\"T-9002\",\"full_name\":\"Test\",\"job_grade\":\"الدرجة الخامسة\"}"</pre>
  <p class="hint">ويوجد ملف <code>postman_collection.json</code> في مجلد المنصة لاستيراده في Postman.</p>
</section>

<script>
const BASE = <?= json_encode($base) ?>;
const $ = id => document.getElementById(id);
async function call(method, path, body, token) {
  const opt = { method, headers: { 'Content-Type': 'application/json' } };
  if (token) opt.headers['Authorization'] = 'Bearer ' + token;
  if (body && method !== 'GET' && method !== 'DELETE') opt.body = body;
  try {
    const res = await fetch(BASE + '/' + path.replace(/^\//, ''), opt);
    const text = await res.text();
    $('t_out').textContent = method + ' ' + path + '\nHTTP ' + res.status + '\n\n' + text;
    try { return JSON.parse(text); } catch { return null; }
  } catch (e) { $('t_out').textContent = 'تعذر الاتصال: ' + e.message; }
}
$('b_login').onclick = async () => {
  const r = await call('POST', 'login.php', JSON.stringify({ username: $('t_user').value, password: $('t_pass').value }));
  if (r && r.token) $('t_token').value = r.token;
};
$('b_send').onclick = () => call($('t_method').value, $('t_path').value, $('t_body').value, $('t_token').value.trim());
</script>
<?php render_footer();
