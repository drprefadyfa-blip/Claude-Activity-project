<?php
// إدارة الجهات المسموح لها باستخدام الـ API
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
require_login();

try {
    $pdo = db();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_check();
        $action = $_POST['action'] ?? '';
        if ($action === 'add') {
            $name = trim($_POST['client_name'] ?? '');
            $username = trim($_POST['api_username'] ?? '');
            $password = (string)($_POST['api_password'] ?? '');
            if ($name === '' || !preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $username) || strlen($password) < 8) {
                flash('bad', 'أدخل اسم الجهة، واسم مستخدم إنجليزي من 3 أحرف على الأقل، وكلمة مرور من 8 أحرف على الأقل.');
            } else {
                $exists = $pdo->prepare('SELECT id FROM api_clients WHERE api_username = ?');
                $exists->execute([$username]);
                if ($exists->fetch()) {
                    flash('bad', 'اسم المستخدم موجود مسبقاً');
                } else {
                    $pdo->prepare('INSERT INTO api_clients (client_name, api_username, api_password_hash, is_active, created_at) VALUES (?,?,?,1,?)')
                        ->execute([$name, $username, password_hash($password, PASSWORD_DEFAULT), now()]);
                    flash('ok', "تمت إضافة الجهة. بيانات الربط:\nAPI Username: $username\nAPI Password: $password\n(احفظ كلمة المرور، فهي لا تُعرض مرة أخرى)");
                }
            }
        } elseif ($action === 'toggle') {
            $pdo->prepare('UPDATE api_clients SET is_active = 1 - is_active WHERE id = ?')->execute([(int)$_POST['id']]);
            flash('ok', 'تم تغيير حالة الجهة');
        } elseif ($action === 'revoke') {
            $pdo->prepare('DELETE FROM api_tokens WHERE client_id = ?')->execute([(int)$_POST['id']]);
            flash('ok', 'تم إلغاء كل التوكنات الصادرة لهذه الجهة');
        }
        redirect('api_clients.php');
    }

    $clients = $pdo->prepare('SELECT c.*, (SELECT COUNT(*) FROM api_tokens t WHERE t.client_id = c.id AND t.expires_at > ?) AS active_tokens FROM api_clients c ORDER BY c.id');
    $clients->execute([now()]);
    $clients = $clients->fetchAll();
} catch (Throwable $e) {
    db_error_page($e);
}

render_header('حسابات الـ API', 'api_clients.php');
?>
<div class="grid-2-1">
  <section class="card">
    <h2>الجهات المرتبطة بالـ API</h2>
    <div class="tbl"><table>
      <thead><tr><th>الجهة</th><th>API Username</th><th>الحالة</th><th>توكنات فعالة</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($clients as $c): ?>
        <tr>
          <td><b><?= e($c['client_name']) ?></b></td>
          <td class="ltr"><?= e($c['api_username']) ?></td>
          <td><?= $c['is_active'] ? '<span class="pill ok">مفعّل</span>' : '<span class="pill bad">موقوف</span>' ?></td>
          <td class="num"><?= (int)$c['active_tokens'] ?></td>
          <td style="white-space:nowrap">
            <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="ghost small"><?= $c['is_active'] ? 'إيقاف' : 'تفعيل' ?></button></form>
            <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="revoke"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="danger small">إلغاء التوكنات</button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <p class="hint">إيقاف الجهة يرفض كل طلباتها فوراً. وإلغاء التوكنات يجبرها على تسجيل الدخول من جديد.</p>
  </section>
  <section class="card">
    <h2>إضافة جهة جديدة</h2>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="add">
      <label for="client_name">اسم الجهة</label><input id="client_name" name="client_name" required>
      <label for="api_username">API Username (بالإنجليزية)</label><input id="api_username" name="api_username" class="ltr" required pattern="[A-Za-z0-9_.\-]{3,50}">
      <label for="api_password">API Password (8 أحرف على الأقل)</label><input id="api_password" name="api_password" class="ltr" required minlength="8">
      <div class="actions"><button type="submit">إضافة</button></div>
    </form>
  </section>
</div>
<?php render_footer();
