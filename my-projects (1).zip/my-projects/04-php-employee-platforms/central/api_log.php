<?php
// سجل طلبات الـ API
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
require_login();

try {
    $logs = db()->query('SELECT * FROM api_log ORDER BY id DESC LIMIT 200')->fetchAll();
} catch (Throwable $e) {
    db_error_page($e);
}

render_header('سجل الـ API', 'api_log.php');
?>
<section class="card">
  <h2>آخر 200 طلب على الـ API</h2>
  <div class="tbl"><table>
    <thead><tr><th>الوقت</th><th>الجهة</th><th>الطلب</th><th>المسار</th><th>النتيجة</th><th>IP</th></tr></thead>
    <tbody>
    <?php if (!$logs): ?><tr><td colspan="6" class="empty">لا توجد طلبات بعد.</td></tr><?php endif; ?>
    <?php foreach ($logs as $l):
        $cls = $l['status_code'] < 300 ? 'ok' : ($l['status_code'] < 500 ? 'bad' : 'bad'); ?>
      <tr>
        <td class="num"><?= e($l['created_at']) ?></td>
        <td><?= e($l['client_name'] ?? '-') ?></td>
        <td><span class="method m-<?= strtolower(e($l['method'])) ?>"><?= e($l['method']) ?></span></td>
        <td class="ltr"><?= e($l['endpoint']) ?></td>
        <td><span class="pill <?= $cls ?>"><?= (int)$l['status_code'] ?></span></td>
        <td class="ltr"><?= e($l['ip']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</section>
<?php render_footer();
