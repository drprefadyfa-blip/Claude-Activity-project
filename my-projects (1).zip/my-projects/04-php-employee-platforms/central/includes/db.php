<?php
// الاتصال بقاعدة البيانات عبر PDO
function db(): PDO
{
    static $pdo = null;
    if ($pdo) return $pdo;

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    if (defined('DB_DSN')) {
        // للاختبار فقط (يُضبط في config.local.php)
        $pdo = new PDO(DB_DSN, null, null, $options);
    } else {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    }
    return $pdo;
}

// رسالة واضحة إذا لم تكن قاعدة البيانات جاهزة
function db_error_page(Throwable $e): void
{
    http_response_code(500);
    echo '<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>خطأ في قاعدة البيانات</title>'
       . '<body style="font-family:Tahoma,sans-serif;max-width:640px;margin:60px auto;padding:0 16px;line-height:1.8">'
       . '<h2>تعذر الاتصال بقاعدة البيانات</h2>'
       . '<ol><li>تأكد أن <b>Apache</b> و<b>MySQL</b> يعملان في XAMPP Control Panel.</li>'
       . '<li>افتح صفحة التثبيت: <a href="install.php">install.php</a></li>'
       . '<li>أو استورد ملف <code>database.sql</code> من phpMyAdmin.</li></ol>'
       . '<p style="color:#888;direction:ltr;text-align:left;font-size:13px">' . htmlspecialchars($e->getMessage()) . '</p>'
       . '</body></html>';
    exit;
}
