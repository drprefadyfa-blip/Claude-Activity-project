<?php
// الدوال المساعدة المشتركة

// الدرجات الوظيفية المعتمدة
const JOB_GRADES = [
    'الدرجة الأولى', 'الدرجة الثانية', 'الدرجة الثالثة', 'الدرجة الرابعة', 'الدرجة الخامسة',
    'الدرجة السادسة', 'الدرجة السابعة', 'الدرجة الثامنة', 'الدرجة التاسعة', 'الدرجة العاشرة',
];

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function start_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name('SID_' . strtoupper(APP_CODE)); // جلسة مستقلة لكل منصة
        session_start();
    }
}

function current_user(): ?array
{
    start_session();
    return $_SESSION['user'] ?? null;
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        header('Location: login.php');
        exit;
    }
    return $user;
}

function csrf_token(): string
{
    start_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    start_session();
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400);
        exit('طلب غير صالح (CSRF). أعد تحميل الصفحة وحاول مرة أخرى.');
    }
}

function flash(?string $type = null, ?string $message = null): ?array
{
    start_session();
    if ($type !== null) {
        $_SESSION['flash'] = ['type' => $type, 'message' => $message];
        return null;
    }
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

// التحقق من بيانات الموظف وتنظيفها
function validate_employee(array $in): array
{
    $data = [
        'employee_no' => trim((string)($in['employee_no'] ?? '')),
        'full_name'   => trim((string)($in['full_name'] ?? '')),
        'job_grade'   => trim((string)($in['job_grade'] ?? '')),
        'job_title'   => trim((string)($in['job_title'] ?? '')),
        'department'  => trim((string)($in['department'] ?? '')),
    ];
    $errors = [];
    if ($data['employee_no'] === '' || mb_strlen($data['employee_no']) > 30) $errors[] = 'الرقم الوظيفي مطلوب (حتى 30 حرفاً)';
    if ($data['full_name'] === '' || mb_strlen($data['full_name']) > 150)   $errors[] = 'اسم الموظف مطلوب (حتى 150 حرفاً)';
    if (!in_array($data['job_grade'], JOB_GRADES, true))                    $errors[] = 'الدرجة الوظيفية غير صحيحة. القيم المسموحة: ' . implode('، ', JOB_GRADES);
    if (mb_strlen($data['job_title']) > 150)                                 $errors[] = 'العنوان الوظيفي طويل جداً';
    if (mb_strlen($data['department']) > 150)                                $errors[] = 'اسم القسم طويل جداً';
    return [$errors, $data];
}
