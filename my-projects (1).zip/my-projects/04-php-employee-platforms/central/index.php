<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
$user = require_login();

try {
    $pdo = db();

    // ===== الإضافة / التعديل / الحذف =====
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_check();
        $action = $_POST['action'] ?? '';

        if ($action === 'save') {
            [$errors, $data] = validate_employee($_POST);
            $id = (int)($_POST['id'] ?? 0);
            if (!$errors) {
                $dup = $pdo->prepare('SELECT id FROM employees WHERE employee_no = ? AND id <> ?');
                $dup->execute([$data['employee_no'], $id]);
                if ($dup->fetch()) $errors[] = 'الرقم الوظيفي مستخدم لموظف آخر';
            }
            if ($errors) {
                flash('bad', implode("\n", $errors));
                redirect('index.php' . ($id ? '?edit=' . $id : ''));
            }
            if ($id) {
                $stmt = $pdo->prepare('UPDATE employees SET employee_no=?, full_name=?, job_grade=?, job_title=?, department=?, updated_at=? WHERE id=?');
                $stmt->execute([$data['employee_no'], $data['full_name'], $data['job_grade'], $data['job_title'], $data['department'], now(), $id]);
                flash('ok', 'تم تعديل بيانات الموظف ' . $data['full_name']);
            } else {
                $stmt = $pdo->prepare('INSERT INTO employees (employee_no, full_name, job_grade, job_title, department, source_platform, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)');
                $stmt->execute([$data['employee_no'], $data['full_name'], $data['job_grade'], $data['job_title'], $data['department'], 'central', now(), now()]);
                flash('ok', 'تمت إضافة الموظف ' . $data['full_name']);
            }
            redirect('index.php');
        }

        if ($action === 'delete') {
            $pdo->prepare('DELETE FROM employees WHERE id = ?')->execute([(int)$_POST['id']]);
            flash('ok', 'تم حذف الموظف');
            redirect('index.php');
        }
    }

    // ===== البحث والفلترة =====
    $q = trim($_GET['q'] ?? '');
    $grade = $_GET['grade'] ?? '';
    $where = [];
    $params = [];
    if ($q !== '') { $where[] = '(full_name LIKE ? OR employee_no LIKE ? OR department LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
    if ($grade !== '') { $where[] = 'job_grade = ?'; $params[] = $grade; }
    $sql = 'SELECT * FROM employees' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY id DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $employees = $stmt->fetchAll();

    $total = (int)$pdo->query('SELECT COUNT(*) FROM employees')->fetchColumn();
    $fromApi = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE source_platform <> 'central'")->fetchColumn();
    $apiToday = $pdo->prepare('SELECT COUNT(*) FROM api_log WHERE created_at >= ?');
    $apiToday->execute([date('Y-m-d 00:00:00')]);
    $apiToday = (int)$apiToday->fetchColumn();

    $edit = null;
    if (isset($_GET['edit'])) {
        $s = $pdo->prepare('SELECT * FROM employees WHERE id = ?');
        $s->execute([(int)$_GET['edit']]);
        $edit = $s->fetch() ?: null;
    }
} catch (Throwable $e) {
    db_error_page($e);
}

render_header('الموظفون', 'index.php');
?>
<div class="stats">
  <div class="stat"><span>إجمالي الموظفين</span><b><?= $total ?></b></div>
  <div class="stat"><span>وردوا عبر الـ API</span><b><?= $fromApi ?></b></div>
  <div class="stat"><span>طلبات API اليوم</span><b><?= $apiToday ?></b></div>
</div>

<div class="grid-2-1">
  <section class="card">
    <h2>قائمة الموظفين</h2>
    <form method="get" class="row">
      <div><label for="q">بحث بالاسم أو الرقم أو القسم</label><input id="q" name="q" value="<?= e($q) ?>"></div>
      <div><label for="grade">الدرجة الوظيفية</label>
        <select id="grade" name="grade"><option value="">الكل</option>
          <?php foreach (JOB_GRADES as $g): ?><option <?= $g === $grade ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?>
        </select></div>
      <div style="flex:0 0 auto"><button type="submit">بحث</button></div>
    </form>
    <div class="tbl" style="margin-top:12px">
      <table>
        <thead><tr><th>الرقم الوظيفي</th><th>اسم الموظف</th><th>الدرجة الوظيفية</th><th>العنوان الوظيفي</th><th>القسم</th><th>المصدر</th><th></th></tr></thead>
        <tbody>
        <?php if (!$employees): ?><tr><td colspan="7" class="empty">لا توجد نتائج.</td></tr><?php endif; ?>
        <?php foreach ($employees as $emp): ?>
          <tr>
            <td class="code"><?= e($emp['employee_no']) ?></td>
            <td><b><?= e($emp['full_name']) ?></b></td>
            <td><span class="pill"><?= e($emp['job_grade']) ?></span></td>
            <td><?= e($emp['job_title']) ?></td>
            <td><?= e($emp['department']) ?></td>
            <td><?= $emp['source_platform'] === 'central' ? '<span class="pill muted">محلي</span>' : '<span class="pill ok">API: ' . e($emp['source_platform']) . '</span>' ?></td>
            <td style="white-space:nowrap">
              <a class="btn ghost small" href="?edit=<?= (int)$emp['id'] ?>">تعديل</a>
              <form method="post" onsubmit="return confirm('حذف الموظف؟')"><?= csrf_field() ?>
                <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$emp['id'] ?>">
                <button class="danger small" type="submit">حذف</button></form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <section class="card">
    <h2><?= $edit ? 'تعديل موظف' : 'إضافة موظف' ?></h2>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <label for="employee_no">الرقم الوظيفي</label>
      <input id="employee_no" name="employee_no" required maxlength="30" value="<?= e($edit['employee_no'] ?? '') ?>">
      <label for="full_name">اسم الموظف</label>
      <input id="full_name" name="full_name" required maxlength="150" value="<?= e($edit['full_name'] ?? '') ?>">
      <label for="job_grade">الدرجة الوظيفية</label>
      <select id="job_grade" name="job_grade" required>
        <?php foreach (JOB_GRADES as $g): ?><option <?= $g === ($edit['job_grade'] ?? '') ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?>
      </select>
      <label for="job_title">العنوان الوظيفي</label>
      <input id="job_title" name="job_title" maxlength="150" value="<?= e($edit['job_title'] ?? '') ?>">
      <label for="department">القسم</label>
      <input id="department" name="department" maxlength="150" value="<?= e($edit['department'] ?? '') ?>">
      <div class="actions">
        <button type="submit"><?= $edit ? 'حفظ التعديل' : 'إضافة' ?></button>
        <?php if ($edit): ?><a class="btn ghost" href="index.php">إلغاء</a><?php endif; ?>
      </div>
    </form>
  </section>
</div>
<?php render_footer();
