<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
start_session();

if (current_user()) redirect('index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $stmt = db()->prepare('SELECT * FROM users WHERE username = ?');
        $stmt->execute([trim($_POST['username'] ?? '')]);
        $user = $stmt->fetch();
    } catch (Throwable $e) {
        db_error_page($e);
    }
    if ($user && password_verify($_POST['password'] ?? '', $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => $user['id'], 'username' => $user['username'], 'full_name' => $user['full_name']];
        redirect('index.php');
    }
    $error = 'اسم المستخدم أو كلمة المرور غير صحيحة';
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>تسجيل الدخول | <?= e(APP_NAME) ?></title><link rel="stylesheet" href="assets/style.css"></head>
<body class="platform-<?= e(APP_CODE) ?>">
<div class="login-box">
  <div class="card">
    <h1><?= e(APP_NAME) ?></h1>
    <p>تسجيل الدخول إلى منصة بيانات الموظفين</p>
    <?php if ($error): ?><div class="alert bad"><?= e($error) ?></div><?php endif; ?>
    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <label for="username">اسم المستخدم</label>
      <input id="username" name="username" required autofocus value="<?= e($_POST['username'] ?? '') ?>">
      <label for="password">كلمة المرور</label>
      <input id="password" name="password" type="password" required>
      <div class="actions"><button type="submit" style="width:100%">دخول</button></div>
    </form>
    <p class="hint" style="margin-top:14px">للتجربة: <code>admin</code> / <code>Admin@123</code></p>
    <p class="hint"><a href="network.php">الدخول من حاسبة أخرى في الشبكة</a></p>
  </div>
</div>
</body>
</html>
