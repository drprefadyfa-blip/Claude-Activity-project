# توثيق API الجهاز المركزي

الإصدار 1.0. الـ API مكتوب بلغة PHP مع قاعدة بيانات MySQL.

## معلومات الربط

| البند | القيمة |
|---|---|
| Base URL (نفس الجهاز) | `http://localhost/central/api` |
| Base URL (جهاز آخر في الشبكة) | `http://<IP جهاز الجهاز المركزي>/central/api` |
| المنفذ | `80`، وهو منفذ Apache الافتراضي في XAMPP |
| المصادقة | `username` و`password` ← توكن `Bearer` |
| صلاحية التوكن | 3600 ثانية (ساعة). تتغير من `TOKEN_TTL` في `config.php` |
| صيغة البيانات | `application/json; charset=utf-8` |
| ترويسة التوكن | `Authorization: Bearer <token>`، والبديل `X-API-Token: <token>` |

### حساب التجربة

| الجهة | API Username | API Password |
|---|---|---|
| مديرية الجريمة المنظمة | `crime_api` | `Crime@2026` |

تضاف جهات جديدة من صفحة **حسابات الـ API** في واجهة الجهاز المركزي.

## الدرجات الوظيفية المسموحة

الدرجة الأولى، الدرجة الثانية، الدرجة الثالثة، الدرجة الرابعة، الدرجة الخامسة، الدرجة السادسة، الدرجة السابعة، الدرجة الثامنة، الدرجة التاسعة، الدرجة العاشرة.

---

## 1) فحص الاتصال

`GET /info.php`، ولا يحتاج توكن.

```json
{ "success": true, "platform": "الجهاز المركزي", "version": "1.0", "time": "2026-10-06 14:00:00",
  "endpoints": { "...": "..." }, "job_grades": ["الدرجة الأولى", "..."] }
```

## 2) تسجيل الدخول والحصول على التوكن

`POST /login.php`

```json
{ "username": "crime_api", "password": "Crime@2026" }
```

الرد `200`:

```json
{ "success": true, "token": "7fcfa11c6ed5...64 حرفاً", "token_type": "Bearer",
  "expires_in": 3600, "expires_at": "2026-10-06 15:00:00", "client": "مديرية الجريمة المنظمة" }
```

## 3) قائمة الموظفين

`GET /employees.php`

| معامل اختياري | مثال |
|---|---|
| `grade` | `?grade=الدرجة الثالثة` |
| `department` | `?department=القسم المالي` |
| `search` | `?search=أحمد` (بالاسم أو الرقم الوظيفي) |

```json
{ "success": true, "count": 1, "data": [
  { "id": 1, "employee_no": "C-1001", "full_name": "أحمد كاظم جواد", "job_grade": "الدرجة الثالثة",
    "job_title": "مدير قسم", "department": "قسم الموارد البشرية", "source_platform": "central",
    "created_at": "2026-10-06 09:00:00", "updated_at": "2026-10-06 09:00:00" } ] }
```

## 4) موظف واحد

- `GET /employees.php?id=1`
- `GET /employees.php?employee_no=C-1001`

## 5) إضافة موظف

`POST /employees.php`

```json
{ "employee_no": "OC-2001", "full_name": "حسين جاسم محمد", "job_grade": "الدرجة الرابعة",
  "job_title": "محقق", "department": "شعبة التحقيقات" }
```

| الحقل | مطلوب | الوصف |
|---|---|---|
| `employee_no` | نعم | الرقم الوظيفي، فريد، حتى 30 حرفاً |
| `full_name` | نعم | اسم الموظف، حتى 150 حرفاً |
| `job_grade` | نعم | من قائمة الدرجات الوظيفية |
| `job_title` | لا | العنوان الوظيفي |
| `department` | لا | القسم أو الشعبة |

- **الرد `201`:** تمت الإضافة، ويحفظ في `source_platform` اسم مستخدم الجهة المرسلة.
- **الرد `409`:** الرقم الوظيفي موجود مسبقاً، ويعيد `existing_id` لتستخدمه في التعديل بـ PUT.
- **الرد `422`:** خطأ في البيانات، مع `details` و`allowed_grades`.

## 6) تعديل موظف

`PUT /employees.php?id=6`، بنفس حقول الإضافة.

## 7) حذف موظف

`DELETE /employees.php?id=6`

---

## رموز الردود

| الرمز | المعنى |
|---|---|
| `200` | نجاح |
| `201` | تمت الإضافة |
| `400` | JSON غير صحيح، أو حقول تسجيل الدخول ناقصة |
| `401` | التوكن مفقود أو غير صالح أو منتهٍ (`code: token_expired`)، أو بيانات دخول خاطئة |
| `403` | حساب الجهة موقوف |
| `404` | الموظف غير موجود |
| `405` | نوع الطلب غير مدعوم |
| `409` | الرقم الوظيفي موجود |
| `422` | بيانات الموظف غير صحيحة |
| `500` | خطأ في الخادم أو قاعدة البيانات |

شكل الخطأ دائماً:

```json
{ "success": false, "error": "رسالة الخطأ" }
```

---

## أمثلة curl (ويندوز CMD)

```bat
curl -X POST "http://localhost/central/api/login.php" -H "Content-Type: application/json" -d "{\"username\":\"crime_api\",\"password\":\"Crime@2026\"}"

curl "http://localhost/central/api/employees.php" -H "Authorization: Bearer TOKEN"

curl -X POST "http://localhost/central/api/employees.php" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"employee_no\":\"T-1\",\"full_name\":\"Test\",\"job_grade\":\"الدرجة الخامسة\"}"
```

## مثال PHP (الـ API Client)

هذا مختصر لما في `organized_crime/includes/api_client.php`:

```php
$base = 'http://localhost/central/api';

// 1) تسجيل الدخول
$ch = curl_init("$base/login.php");
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode(['username' => 'crime_api', 'password' => 'Crime@2026']),
]);
$token = json_decode(curl_exec($ch), true)['token'];

// 2) جلب الموظفين بالتوكن
$ch = curl_init("$base/employees.php");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ["Authorization: Bearer $token"],
]);
$employees = json_decode(curl_exec($ch), true)['data'];
```

## Postman

استورد ملف `postman_collection.json`، ثم شغّل طلب **Login** أولاً. يحفظ الطلب التوكن تلقائياً في المتغير `token` لتستخدمه بقية الطلبات.

## الأمان

- **التوكنات:** تُحفظ في قاعدة البيانات مشفّرة بـ SHA-256 وليس كنص.
- **كلمات المرور:** تُحفظ بـ `password_hash` (bcrypt).
- **السجل:** كل طلب يُسجَّل في جدول `api_log`، ويظهر في صفحة **سجل الـ API**.
- **للاستخدام الفعلي:**
  - استخدم HTTPS.
  - غيّر كلمات المرور الافتراضية.
  - احذف `install.php`.
  - ضع كلمة مرور لمستخدم `root` في MySQL.
