<?php
// =====================================================
// صفحة الوصول من الحاسبات الأخرى في الشبكة (لا تحتاج تسجيل دخول)
// افتحها على حاسبة السيرفر: http://localhost/<اسم المجلد>/network.php
// =====================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/helpers.php';

// اسم مجلد المنصة كما في htdocs (مثل central أو organized_crime)
$folder = trim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$port = (int)($_SERVER['SERVER_PORT'] ?? 80);
$portPart = in_array($port, [80, 443], true) ? '' : ':' . $port;
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';

// قراءة عناوين IPv4 لكل كرت شبكة
$adapters = [];
if (stripos(PHP_OS, 'WIN') === 0 && function_exists('shell_exec')) {
    $out = (string)@shell_exec('ipconfig');
    $out = @iconv('CP850', 'UTF-8//IGNORE', $out) ?: $out;
    $current = 'Network adapter';
    foreach (preg_split('/\r?\n/', $out) as $line) {
        if (preg_match('/^(\S.*adapter .*?):?\s*$/i', $line, $m)) $current = trim($m[1], ' :');
        if (preg_match('/IPv4[^:]*:\s*([\d.]+)/i', $line, $m)) $adapters[] = ['name' => $current, 'ip' => $m[1]];
    }
}
if (!$adapters) {
    foreach ((array)@gethostbynamel(gethostname()) as $ip) $adapters[] = ['name' => 'Network adapter', 'ip' => $ip];
    if (!empty($_SERVER['SERVER_ADDR']) && filter_var($_SERVER['SERVER_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $adapters[] = ['name' => 'Current connection', 'ip' => $_SERVER['SERVER_ADDR']];
    }
}
// ترتيب: عناوين الشبكة المحلية أولاً، وتعليم الكروت الافتراضية
$seen = [];
$list = [];
foreach ($adapters as $a) {
    if (isset($seen[$a['ip']]) || strpos($a['ip'], '127.') === 0 || strpos($a['ip'], '169.254.') === 0) continue;
    $seen[$a['ip']] = true;
    $a['virtual'] = (bool)preg_match('/virtualbox|vmware|hyper-v|vethernet|wsl|docker|loopback|vpn|tap|bluetooth/i', $a['name']);
    $list[] = $a;
}
usort($list, fn($x, $y) => $x['virtual'] <=> $y['virtual']);

$remoteIp = $_SERVER['REMOTE_ADDR'] ?? '';
$isLocal = in_array($remoteIp, ['127.0.0.1', '::1'], true);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>الوصول من الشبكة | <?= e(APP_NAME) ?></title><link rel="stylesheet" href="assets/style.css"></head>
<body class="platform-<?= e(APP_CODE) ?>">
<header class="topbar"><div class="brand"><span class="mark" aria-hidden="true"><?= e(APP_MARK) ?></span>
  <div><b><?= e(APP_NAME) ?></b><small>الوصول من الحاسبات الأخرى في الشبكة</small></div></div></header>
<main class="wrap">

<?php if ($isLocal): ?>
  <div class="alert ok">أنت تفتح هذه الصفحة من حاسبة السيرفر نفسها. انسخ أحد الروابط أدناه وافتحه من الحاسبة الأخرى.</div>
<?php else: ?>
  <div class="alert ok">نجح الوصول من حاسبة أخرى. عنوان حاسبتك: <span class="ltr"><?= e($remoteIp) ?></span></div>
<?php endif; ?>

<section class="card">
  <h2>الروابط التي تُفتح من الحاسبات الأخرى</h2>
  <?php if (!$list): ?>
    <p>لم أستطع قراءة عنوان IP تلقائياً. افتح <b>CMD</b> على حاسبة السيرفر واكتب <code>ipconfig</code>، وخذ قيمة <b>IPv4 Address</b> لكرت الشبكة المتصل (Wi-Fi أو Ethernet).</p>
  <?php else: ?>
  <div class="tbl"><table>
    <thead><tr><th>كرت الشبكة</th><th>IP</th><th>رابط المنصة</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($list as $i => $a): $url = "$scheme://{$a['ip']}$portPart/$folder/login.php"; ?>
      <tr>
        <td><?= e($a['name']) ?></td>
        <td class="num"><?= e($a['ip']) ?></td>
        <td class="ltr"><a href="<?= e($url) ?>"><?= e($url) ?></a></td>
        <td><?= $a['virtual'] ? '<span class="pill muted">افتراضي، لا تستخدمه</span>' : ($i === 0 ? '<span class="pill ok">استخدم هذا</span>' : '') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
  <p class="hint">اكتب الرابط كاملاً مع اسم المجلد <code>/<?= e($folder) ?>/</code>. وكلمة <code>localhost</code> لا تعمل من الحاسبات الأخرى، لأنها تعني الحاسبة نفسها.</p>
</section>

<div class="grid">
<section class="card">
  <h2>إذا ظهر 404 Not Found</h2>
  <p>الطلب وصل إلى سيرفر ويب، لكن العنوان أو المسار غير صحيح:</p>
  <ul>
    <li>تأكد أن الرابط فيه اسم المجلد: <code>/<?= e($folder) ?>/login.php</code></li>
    <li>استخدم IP كرت الشبكة الحقيقي (Wi-Fi أو Ethernet)، وليس كرت VirtualBox أو VMware.</li>
    <li>تأكد أن المجلد موجود في <code>C:\xampp\htdocs\<?= e($folder) ?></code></li>
    <li>جرّب أولاً <code>http://IP/<?= e($folder) ?>/network.php</code> من الحاسبة الأخرى.</li>
  </ul>
</section>
<section class="card">
  <h2>إذا لم تفتح الصفحة أبداً (انتهت المهلة)</h2>
  <p>الجدار الناري في ويندوز يمنع الاتصال:</p>
  <ul>
    <li>على حاسبة السيرفر، اضغط بالزر الأيمن على <code>allow-network-access.bat</code> واختر <b>Run as administrator</b>.</li>
    <li>تأكد أن الحاسبتين على نفس الشبكة (نفس الراوتر أو الـ Wi-Fi).</li>
    <li>اجعل نوع الشبكة <b>Private</b> من إعدادات Wi-Fi أو Ethernet في ويندوز.</li>
  </ul>
</section>
</div>
</main>
<footer class="foot"><?= e(APP_NAME) ?></footer>
</body>
</html>
