<?php
// =====================================================
// إعدادات منصة الجهاز المركزي
// =====================================================
if (file_exists(__DIR__ . '/config.local.php')) require __DIR__ . '/config.local.php';

defined('APP_NAME')  || define('APP_NAME', 'الجهاز المركزي');
defined('APP_CODE')  || define('APP_CODE', 'central');
defined('APP_MARK')  || define('APP_MARK', 'م');   // حرف الشعار

// قاعدة البيانات (إعدادات XAMPP الافتراضية)
defined('DB_HOST')   || define('DB_HOST', '127.0.0.1');
defined('DB_PORT')   || define('DB_PORT', 3306);
defined('DB_NAME')   || define('DB_NAME', 'central_db');
defined('DB_USER')   || define('DB_USER', 'root');
defined('DB_PASS')   || define('DB_PASS', '');

// صلاحية توكن الـ API بالثواني (ساعة واحدة)
defined('TOKEN_TTL') || define('TOKEN_TTL', 3600);

date_default_timezone_set('Asia/Baghdad');
