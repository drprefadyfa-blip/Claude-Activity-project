<?php
// =====================================================
// صفحة التثبيت: تنشئ قاعدة البيانات والجداول والبيانات الأولية
// افتح: http://localhost/central/install.php
// =====================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/helpers.php';

$messages = [];
$ok = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (defined('DB_DSN')) throw new RuntimeException('صفحة التثبيت تعمل مع MySQL فقط.');
        $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4', DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $sql = file_get_contents(__DIR__ . '/database.sql');
        $sql = preg_replace('/^\s*--.*$/m', '', $sql);           // حذف التعليقات
        $statements = array_filter(array_map('trim', explode(";\n", str_replace("\r\n", "\n", $sql))));
        foreach ($statements as $stmt) {
            $pdo->exec(rtrim($stmt, ';'));
        }
        $count = $pdo->query('SELECT COUNT(*) FROM ' . DB_NAME . '.employees')->fetchColumn();
        $messages[] = ['ok', 'تم إنشاء قاعدة البيانات «' . DB_NAME . '» والجداول بنجاح. عدد الموظفين: ' . $count];
        $ok = true;
    } catch (Throwable $e) {
        $messages[] = ['bad', 'فشل التثبيت: ' . $e->getMessage()];
    }
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>تثبيت <?= e(APP_NAME) ?></title><link rel="stylesheet" href="assets/style.css"></head>
<body class="platform-<?= e(APP_CODE) ?>">
<div class="login-box" style="max-width:560px">
  <div class="card">
    <h1>تثبيت منصة <?= e(APP_NAME) ?></h1>
    <p>تنشئ هذه الصفحة قاعدة البيانات <code><?= e(DB_NAME) ?></code> والجداول وبيانات تجريبية.</p>
    <?php foreach ($messages as [$t, $m]): ?><div class="alert <?= $t ?>"><?= e($m) ?></div><?php endforeach; ?>
    <?php if ($ok): ?>
      <p style="margin-top:12px">بيانات الدخول للواجهة: <code>admin</code> / <code>Admin@123</code></p>
      <div class="actions"><a class="btn" href="login.php">الذهاب إلى تسجيل الدخول</a></div>
      <p class="hint" style="margin-top:12px">بعد انتهاء التجربة، احذف ملف install.php أو غيّر اسمه.</p>
    <?php else: ?>
      <ul class="hint">
        <li>تأكد أن <b>MySQL</b> يعمل في XAMPP Control Panel.</li>
        <li>الإعدادات الحالية: المستخدم <code><?= e(DB_USER) ?></code> على <code><?= e(DB_HOST) ?>:<?= e(DB_PORT) ?></code> (من ملف config.php).</li>
        <li>التثبيت آمن للتكرار، ولا يحذف بيانات موجودة.</li>
      </ul>
      <form method="post"><div class="actions"><button type="submit">تثبيت قاعدة البيانات</button></div></form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
