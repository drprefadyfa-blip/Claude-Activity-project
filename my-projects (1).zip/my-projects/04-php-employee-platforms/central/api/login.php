<?php
// =====================================================
// POST /api/login.php
// يستقبل: { "username": "...", "password": "..." }
// يعيد:   { "success": true, "token": "...", "expires_in": 3600 }
// =====================================================
require_once __DIR__ . '/_api.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') api_error(405, 'استخدم POST');

$body = read_json_body();
$username = trim((string)($body['username'] ?? ''));
$password = (string)($body['password'] ?? '');
if ($username === '' || $password === '') api_error(400, 'username و password مطلوبان');

$stmt = db()->prepare('SELECT * FROM api_clients WHERE api_username = ?');
$stmt->execute([$username]);
$client = $stmt->fetch();

if (!$client || !password_verify($password, $client['api_password_hash'])) {
    api_error(401, 'اسم المستخدم أو كلمة المرور خاطئة');
}
$GLOBALS['api_client_name'] = $client['client_name'];
if (!$client['is_active']) api_error(403, 'حساب الجهة موقوف');

// حذف التوكنات المنتهية لهذه الجهة ثم إصدار توكن جديد
db()->prepare('DELETE FROM api_tokens WHERE client_id = ? AND expires_at <= ?')->execute([$client['id'], now()]);

$token = bin2hex(random_bytes(32));
$expiresAt = date('Y-m-d H:i:s', time() + TOKEN_TTL);
db()->prepare('INSERT INTO api_tokens (client_id, token_hash, expires_at, created_at) VALUES (?,?,?,?)')
    ->execute([$client['id'], hash('sha256', $token), $expiresAt, now()]);

json_out(200, [
    'success'    => true,
    'token'      => $token,
    'token_type' => 'Bearer',
    'expires_in' => TOKEN_TTL,
    'expires_at' => $expiresAt,
    'client'     => $client['client_name'],
]);
