<?php
// =====================================================
// /api/employees.php   (يحتاج توكن)
//   GET    ?                      قائمة الموظفين (فلترة: grade, department, search)
//   GET    ?id=5                  موظف واحد بالمعرّف
//   GET    ?employee_no=C-1001    موظف واحد بالرقم الوظيفي
//   POST                          إضافة موظف (JSON)
//   PUT    ?id=5                  تعديل موظف (JSON)
//   DELETE ?id=5                  حذف موظف
// =====================================================
require_once __DIR__ . '/_api.php';

$client = require_api_client();
$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

function find_employee(PDO $pdo, string $field, $value): ?array
{
    $stmt = $pdo->prepare("SELECT * FROM employees WHERE $field = ?");
    $stmt->execute([$value]);
    return $stmt->fetch() ?: null;
}

// ---------- GET ----------
if ($method === 'GET') {
    if (isset($_GET['id']) || isset($_GET['employee_no'])) {
        $emp = isset($_GET['id'])
            ? find_employee($pdo, 'id', (int)$_GET['id'])
            : find_employee($pdo, 'employee_no', (string)$_GET['employee_no']);
        if (!$emp) api_error(404, 'الموظف غير موجود');
        json_out(200, ['success' => true, 'data' => employee_out($emp)]);
    }

    $where = [];
    $params = [];
    if (($g = trim($_GET['grade'] ?? '')) !== '')      { $where[] = 'job_grade = ?';  $params[] = $g; }
    if (($d = trim($_GET['department'] ?? '')) !== '') { $where[] = 'department = ?'; $params[] = $d; }
    if (($s = trim($_GET['search'] ?? '')) !== '')     { $where[] = '(full_name LIKE ? OR employee_no LIKE ?)'; array_push($params, "%$s%", "%$s%"); }

    $stmt = $pdo->prepare('SELECT * FROM employees' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY id');
    $stmt->execute($params);
    $rows = array_map('employee_out', $stmt->fetchAll());
    json_out(200, ['success' => true, 'count' => count($rows), 'data' => $rows]);
}

// ---------- POST ----------
if ($method === 'POST') {
    [$errors, $data] = validate_employee(read_json_body());
    if ($errors) api_error(422, 'بيانات غير صحيحة', ['details' => $errors, 'allowed_grades' => JOB_GRADES]);

    if ($existing = find_employee($pdo, 'employee_no', $data['employee_no'])) {
        api_error(409, 'الرقم الوظيفي موجود مسبقاً. استخدم PUT للتعديل', ['existing_id' => (int)$existing['id']]);
    }
    $pdo->prepare('INSERT INTO employees (employee_no, full_name, job_grade, job_title, department, source_platform, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)')
        ->execute([$data['employee_no'], $data['full_name'], $data['job_grade'], $data['job_title'], $data['department'], $client['api_username'], now(), now()]);
    $emp = find_employee($pdo, 'id', (int)$pdo->lastInsertId());
    json_out(201, ['success' => true, 'message' => 'تمت إضافة الموظف', 'data' => employee_out($emp)]);
}

// ---------- PUT ----------
if ($method === 'PUT') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id || !find_employee($pdo, 'id', $id)) api_error(404, 'الموظف غير موجود');
    [$errors, $data] = validate_employee(read_json_body());
    if ($errors) api_error(422, 'بيانات غير صحيحة', ['details' => $errors, 'allowed_grades' => JOB_GRADES]);

    $dup = $pdo->prepare('SELECT id FROM employees WHERE employee_no = ? AND id <> ?');
    $dup->execute([$data['employee_no'], $id]);
    if ($dup->fetch()) api_error(409, 'الرقم الوظيفي مستخدم لموظف آخر');

    $pdo->prepare('UPDATE employees SET employee_no=?, full_name=?, job_grade=?, job_title=?, department=?, updated_at=? WHERE id=?')
        ->execute([$data['employee_no'], $data['full_name'], $data['job_grade'], $data['job_title'], $data['department'], now(), $id]);
    json_out(200, ['success' => true, 'message' => 'تم تعديل الموظف', 'data' => employee_out(find_employee($pdo, 'id', $id))]);
}

// ---------- DELETE ----------
if ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id || !find_employee($pdo, 'id', $id)) api_error(404, 'الموظف غير موجود');
    $pdo->prepare('DELETE FROM employees WHERE id = ?')->execute([$id]);
    json_out(200, ['success' => true, 'message' => 'تم حذف الموظف']);
}

api_error(405, 'نوع الطلب غير مدعوم');
