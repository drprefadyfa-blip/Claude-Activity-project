<?php
// =====================================================
// الدوال المشتركة لكل ملفات الـ API
// =====================================================
require_once __DIR__ . '/../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Token');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

$GLOBALS['api_client_name'] = null;

// تسجيل كل طلب في جدول api_log عند انتهاء التنفيذ
register_shutdown_function(function () {
    try {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        db()->prepare('INSERT INTO api_log (client_name, method, endpoint, status_code, ip, created_at) VALUES (?,?,?,?,?,?)')
            ->execute([$GLOBALS['api_client_name'], $_SERVER['REQUEST_METHOD'] ?? 'CLI', substr($uri, 0, 255),
                       http_response_code() ?: 200, $_SERVER['REMOTE_ADDR'] ?? null, now()]);
    } catch (Throwable $e) { /* لا نوقف الرد بسبب السجل */ }
});

function json_out(int $status, array $body): void
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function api_error(int $status, string $message, array $extra = []): void
{
    json_out($status, ['success' => false, 'error' => $message] + $extra);
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) return $_POST;          // يقبل أيضاً form-data
    $data = json_decode($raw, true);
    if (!is_array($data)) api_error(400, 'صيغة JSON غير صحيحة');
    return $data;
}

// قراءة التوكن من ترويسة Authorization: Bearer ... (مع حلول لمشكلة Apache في XAMPP)
function bearer_token(): ?string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($header === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) {
            if (strcasecmp($k, 'Authorization') === 0) { $header = $v; break; }
        }
    }
    if (preg_match('/^Bearer\s+(\S+)$/i', trim($header), $m)) return $m[1];
    $alt = $_SERVER['HTTP_X_API_TOKEN'] ?? '';                 // بديل: X-API-Token
    return $alt !== '' ? $alt : null;
}

// حارس: يتحقق من التوكن ويعيد بيانات الجهة
function require_api_client(): array
{
    $token = bearer_token();
    if (!$token) api_error(401, 'التوكن مفقود. أرسل الترويسة: Authorization: Bearer <token>');

    $stmt = db()->prepare('SELECT c.*, t.expires_at FROM api_tokens t JOIN api_clients c ON c.id = t.client_id WHERE t.token_hash = ?');
    $stmt->execute([hash('sha256', $token)]);
    $client = $stmt->fetch();

    if (!$client) api_error(401, 'التوكن غير صالح');
    if ($client['expires_at'] <= now()) api_error(401, 'التوكن منتهي الصلاحية. سجّل الدخول من جديد', ['code' => 'token_expired']);
    if (!$client['is_active']) api_error(403, 'حساب الجهة موقوف');

    $GLOBALS['api_client_name'] = $client['client_name'];
    return $client;
}

// تحويل صف قاعدة البيانات إلى شكل الرد
function employee_out(array $row): array
{
    return [
        'id'              => (int)$row['id'],
        'employee_no'     => $row['employee_no'],
        'full_name'       => $row['full_name'],
        'job_grade'       => $row['job_grade'],
        'job_title'       => $row['job_title'],
        'department'      => $row['department'],
        'source_platform' => $row['source_platform'],
        'created_at'      => $row['created_at'],
        'updated_at'      => $row['updated_at'],
    ];
}

set_exception_handler(function (Throwable $e) {
    api_error(500, 'خطأ في الخادم: ' . $e->getMessage());
});
