<?php
// GET /api/info.php  (بدون توكن) — فحص الاتصال ومعلومات الـ API
require_once __DIR__ . '/_api.php';

json_out(200, [
    'success'   => true,
    'platform'  => APP_NAME,
    'version'   => '1.0',
    'time'      => now(),
    'auth'      => 'POST login.php → Bearer token (صالح ' . TOKEN_TTL . ' ثانية)',
    'endpoints' => [
        'POST   login.php'                       => 'تسجيل الدخول والحصول على توكن',
        'GET    employees.php'                   => 'قائمة الموظفين (grade, department, search)',
        'GET    employees.php?id={id}'           => 'موظف واحد',
        'GET    employees.php?employee_no={no}'  => 'موظف واحد بالرقم الوظيفي',
        'POST   employees.php'                   => 'إضافة موظف',
        'PUT    employees.php?id={id}'           => 'تعديل موظف',
        'DELETE employees.php?id={id}'           => 'حذف موظف',
    ],
    'job_grades' => JOB_GRADES,
]);
