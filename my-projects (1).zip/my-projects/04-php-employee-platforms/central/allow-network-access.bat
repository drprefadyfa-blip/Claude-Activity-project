@echo off
chcp 65001 >nul
title Allow network access to XAMPP Apache
echo.
echo  This opens port 80 (Apache / XAMPP) in Windows Firewall
echo  so other computers on the network can open the platforms.
echo.

net session >nul 2>&1
if errorlevel 1 (
  echo  ERROR: Please right-click this file and choose "Run as administrator".
  echo.
  pause
  exit /b
)

netsh advfirewall firewall delete rule name="XAMPP Apache HTTP 80" >nul 2>&1
netsh advfirewall firewall add rule name="XAMPP Apache HTTP 80" dir=in action=allow protocol=TCP localport=80 profile=any

if exist "C:\xampp\apache\bin\httpd.exe" (
  netsh advfirewall firewall delete rule name="XAMPP Apache httpd.exe" >nul 2>&1
  netsh advfirewall firewall add rule name="XAMPP Apache httpd.exe" dir=in action=allow program="C:\xampp\apache\bin\httpd.exe" enable=yes profile=any
)

echo.
echo  Done. Your IPv4 addresses:
ipconfig | findstr /i "IPv4"
echo.
echo  From another computer open:  http://YOUR-IP/central/login.php
echo                         and:  http://YOUR-IP/organized_crime/login.php
echo.
pause
