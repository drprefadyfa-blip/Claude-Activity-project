-- =====================================================
-- قاعدة بيانات منصة الجهاز المركزي
-- طريقة الاستخدام: phpMyAdmin > Import > اختر هذا الملف
-- (أو افتح http://localhost/central/install.php لتنفيذه تلقائياً)
-- =====================================================

CREATE DATABASE IF NOT EXISTS central_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE central_db;

-- مستخدمو الواجهة (اليوزر نيم والباسورد)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- الموظفون
CREATE TABLE IF NOT EXISTS employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_no VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  job_grade VARCHAR(50) NOT NULL,
  job_title VARCHAR(150) NULL,
  department VARCHAR(150) NULL,
  source_platform VARCHAR(50) NOT NULL DEFAULT 'central',
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- الجهات المسموح لها باستخدام الـ API
CREATE TABLE IF NOT EXISTS api_clients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_name VARCHAR(150) NOT NULL,
  api_username VARCHAR(50) NOT NULL UNIQUE,
  api_password_hash VARCHAR(255) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- التوكنات الصادرة (تُحفظ مشفّرة بـ SHA-256)
CREATE TABLE IF NOT EXISTS api_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_tokens_client (client_id),
  CONSTRAINT fk_tokens_client FOREIGN KEY (client_id) REFERENCES api_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- سجل طلبات الـ API
CREATE TABLE IF NOT EXISTS api_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_name VARCHAR(150) NULL,
  method VARCHAR(10) NOT NULL,
  endpoint VARCHAR(255) NOT NULL,
  status_code INT NOT NULL,
  ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===== بيانات أولية للتجربة (أسماء افتراضية) =====

-- مستخدم الواجهة: admin / Admin@123
INSERT IGNORE INTO users (username, password_hash, full_name, created_at) VALUES
('admin', '$2y$10$x1P8QadKhUAbZn.LlBf6zua2Q6CVwW.J2cHt8aSxsANUT.M0gcqYO', 'مدير النظام', NOW());

-- حساب API لمنصة الجريمة المنظمة: crime_api / Crime@2026
INSERT IGNORE INTO api_clients (client_name, api_username, api_password_hash, is_active, created_at) VALUES
('مديرية الجريمة المنظمة', 'crime_api', '$2y$10$ySqXnUYIUBH9/KRIEregJulqr.o1Loa410E2hxJyRepuKRt0R.m2m', 1, NOW());

INSERT IGNORE INTO employees (employee_no, full_name, job_grade, job_title, department, source_platform, created_at, updated_at) VALUES
('C-1001', 'أحمد كاظم جواد', 'الدرجة الثالثة', 'مدير قسم', 'قسم الموارد البشرية', 'central', NOW(), NOW()),
('C-1002', 'زينب علي حسين', 'الدرجة الخامسة', 'محاسب', 'القسم المالي', 'central', NOW(), NOW()),
('C-1003', 'مصطفى حيدر عباس', 'الدرجة الرابعة', 'مبرمج', 'قسم تقنية المعلومات', 'central', NOW(), NOW()),
('C-1004', 'سارة محمد ناصر', 'الدرجة السادسة', 'موظف إداري', 'قسم الموارد البشرية', 'central', NOW(), NOW()),
('C-1005', 'علي حسن كريم', 'الدرجة الثانية', 'معاون مدير عام', 'المكتب الإداري', 'central', NOW(), NOW());
