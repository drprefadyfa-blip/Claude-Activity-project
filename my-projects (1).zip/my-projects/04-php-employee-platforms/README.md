# منصتا الجهاز المركزي ومديرية الجريمة المنظمة (PHP + MySQL)

| المنصة | الدور |
|---|---|
| [central](central/) | **الجهاز المركزي:** يحتفظ ببيانات الموظفين، ويقدم الـ API، ويدير الجهات المسموح لها بالربط |
| [organized_crime](organized_crime/) | **مديرية الجريمة المنظمة:** لها قاعدة بيانات خاصة، وتستلم الموظفين من المركزي وترسل موظفيها إليه |

## التشغيل على XAMPP

1. انسخ المجلدين إلى `C:\xampp\htdocs\`.
2. شغّل **Apache** و**MySQL**.
3. ثبّت قاعدة بيانات كل منصة بفتح صفحة التثبيت الخاصة بها:
   - `http://localhost/central/install.php`
   - `http://localhost/organized_crime/install.php`
4. ادخل بـ `admin` / `Admin@123`.

توثيق الـ API الكامل في [central/API.md](central/API.md).
