#!/bin/sh
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "Node.js غير مثبت. حمّله من https://nodejs.org"; exit 1; }
[ -f .env ] || cp .env.example .env
echo "افتح المتصفح على: http://localhost:4000"
node start.js
