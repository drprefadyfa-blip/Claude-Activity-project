// =====================================================
// المنصة (أ): الخادم الذي يقدم الـ API
// - تسجيل الدخول باسم مستخدم وكلمة مرور وإصدار توكن JWT
// - استقبال البيانات (POST) وإرسالها (GET) لمن يملك توكناً صالحاً
// لا يحتاج أي مكتبة خارجية (Node.js 18 أو أحدث)
// =====================================================
require('../lib/env').loadEnv();
const http = require('http');
const jwt = require('../lib/jwt');
const { sendJson, readJson } = require('../lib/http-utils');

const HOST = process.env.A_HOST || undefined; // فارغ = الاستماع على IPv4 و IPv6 معاً
const PORT = Number(process.env.A_PORT || 3000);
const SECRET = process.env.JWT_SECRET || 'dev-secret';
const EXPIRES_IN = Number(process.env.TOKEN_EXPIRES_IN || 120);
const USERS = { [process.env.A_API_USERNAME || 'platform_b_user']: process.env.A_API_PASSWORD || 'ChangeMe_123' };
const WHITELIST = (process.env.A_IP_WHITELIST || '').split(',').map(s => s.trim()).filter(Boolean);

// البيانات (في الذاكرة للتجربة؛ استبدلها بقاعدة بيانات في الإنتاج)
const orders = [
  { id: 1, customer: 'مثال: أحمد', item: 'فحص دم', amount: 25000, createdAt: new Date().toISOString(), createdBy: 'system' },
];

// التحقق من التوكن: يعيد المستخدم أو يرسل خطأ 401
function requireToken(req, res) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    sendJson(res, 401, { error: 'التوكن مفقود. أرسل Authorization: Bearer <token>' });
    return null;
  }
  try {
    return jwt.verify(header.slice(7), SECRET);
  } catch (e) {
    sendJson(res, 401, { error: e.name === 'TokenExpiredError' ? 'التوكن منتهي الصلاحية' : 'التوكن غير صالح' });
    return null;
  }
}

function validateOrder(body) {
  const errors = [];
  if (!body.customer || typeof body.customer !== 'string' || !body.customer.trim()) errors.push('customer مطلوب (نص)');
  if (!body.item || typeof body.item !== 'string' || !body.item.trim()) errors.push('item مطلوب (نص)');
  if (body.amount === undefined || body.amount === '' || isNaN(Number(body.amount)) || Number(body.amount) < 0) errors.push('amount مطلوب (رقم موجب)');
  return errors;
}

const server = http.createServer(async (req, res) => {
  const ip = (req.socket.remoteAddress || '').replace('::ffff:', '');
  const url = req.url.split('?')[0];
  console.log(`[A] ${new Date().toLocaleTimeString('en-GB')} ${ip} ${req.method} ${url}`);

  try {
    // قائمة IP المسموح لها (إن وُجدت)
    if (WHITELIST.length && !WHITELIST.includes(ip)) {
      return sendJson(res, 403, { error: 'عنوان IP غير مسموح له', ip });
    }

    // معلومات عامة (بدون توكن)
    if (req.method === 'GET' && url === '/') {
      return sendJson(res, 200, {
        platform: 'A',
        status: 'running',
        endpoints: {
          'POST /auth/login': 'تسجيل الدخول والحصول على توكن',
          'GET /api/orders': 'جلب الطلبات (يحتاج توكن)',
          'POST /api/orders': 'إضافة طلب (يحتاج توكن)',
          'GET /api/orders/:id': 'جلب طلب واحد (يحتاج توكن)',
        },
      });
    }
    if (req.method === 'GET' && url === '/health') {
      return sendJson(res, 200, { ok: true, time: new Date().toISOString() });
    }

    // 1) تسجيل الدخول وإصدار التوكن
    if (req.method === 'POST' && url === '/auth/login') {
      const { username, password } = await readJson(req);
      if (!username || !password) return sendJson(res, 400, { error: 'username و password مطلوبان' });
      if (USERS[username] !== password) return sendJson(res, 401, { error: 'اسم المستخدم أو كلمة المرور خاطئة' });
      const token = jwt.sign({ user: username }, SECRET, EXPIRES_IN);
      return sendJson(res, 200, { token, tokenType: 'Bearer', expiresIn: EXPIRES_IN });
    }

    // 2) كل مسارات /api تحتاج توكن
    if (url.startsWith('/api/')) {
      const user = requireToken(req, res);
      if (!user) return;

      if (req.method === 'GET' && url === '/api/orders') {
        return sendJson(res, 200, { count: orders.length, data: orders });
      }

      const one = url.match(/^\/api\/orders\/(\d+)$/);
      if (req.method === 'GET' && one) {
        const order = orders.find(o => o.id === Number(one[1]));
        return order ? sendJson(res, 200, order) : sendJson(res, 404, { error: 'الطلب غير موجود' });
      }

      if (req.method === 'POST' && url === '/api/orders') {
        const body = await readJson(req);
        const errors = validateOrder(body);
        if (errors.length) return sendJson(res, 422, { error: 'بيانات غير صحيحة', details: errors });
        const order = {
          id: orders.length ? orders[orders.length - 1].id + 1 : 1,
          customer: body.customer.trim(),
          item: body.item.trim(),
          amount: Number(body.amount),
          createdAt: new Date().toISOString(),
          createdBy: user.user,
        };
        orders.push(order);
        return sendJson(res, 201, { ok: true, data: order });
      }
    }

    sendJson(res, 404, { error: 'المسار غير موجود' });
  } catch (e) {
    sendJson(res, e.status || 500, { error: e.message || 'خطأ في الخادم' });
  }
});

server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(`[A] ERROR: port ${PORT} is already in use. Close other windows running the project, or change A_PORT in .env`);
  else console.error('[A] ERROR:', e.message);
});

server.listen(PORT, HOST, () => {
  console.log(`[A] Platform A (API) running on http://localhost:${PORT}  (token valid ${EXPIRES_IN}s)`);
});

module.exports = server;
