@echo off
chcp 65001 >nul
title API Bridge Project - KEEP THIS WINDOW OPEN
cd /d "%~dp0"

if not exist "%~dp0start.js" (
  echo.
  echo ERROR: start.js was not found next to this file.
  echo You are probably running it from inside the ZIP.
  echo Right-click the ZIP file, choose "Extract All", then run run-windows.bat from the extracted folder.
  echo.
  pause
  exit /b
)

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo ERROR: Node.js is not installed.
  echo 1^) Download the LTS version from https://nodejs.org and install it.
  echo 2^) Close this window and run run-windows.bat again.
  echo.
  pause
  exit /b
)

echo Node.js version:
node -v

if not exist .env copy .env.example .env >nul

node start.js

echo.
echo The project has stopped.
pause
