// =====================================================
// عميل الربط: تستخدمه المنصة (ب) للاتصال بالمنصة (أ)
// - يسجّل الدخول تلقائياً ويحفظ التوكن
// - يجدد التوكن قبل انتهائه أو عند رد 401
// =====================================================
const BASE_URL = (process.env.API_BASE_URL || 'http://127.0.0.1:3000').replace(/\/$/, '');

let token = null;
let tokenExpiresAt = 0;
const log = []; // آخر خطوات الربط لعرضها في الواجهة

function addLog(step, detail) {
  log.unshift({ time: new Date().toLocaleTimeString('en-GB'), step, detail });
  if (log.length > 30) log.pop();
}

async function login() {
  addLog('LOGIN', `POST ${BASE_URL}/auth/login`);
  const res = await fetch(`${BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: process.env.API_USERNAME, password: process.env.API_PASSWORD }),
    signal: AbortSignal.timeout(10000),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    addLog('LOGIN FAILED', `${res.status} ${data.error || ''}`);
    const err = new Error(data.error || `فشل تسجيل الدخول (${res.status})`);
    err.status = res.status;
    throw err;
  }
  token = data.token;
  // نجدد قبل الانتهاء بـ 10 ثوانٍ
  tokenExpiresAt = Date.now() + (Number(data.expiresIn || 3600) - 10) * 1000;
  addLog('TOKEN OK', `صالح ${data.expiresIn} ثانية`);
}

async function apiRequest(method, path, body, retried = false) {
  if (!token || Date.now() >= tokenExpiresAt) await login();

  addLog('REQUEST', `${method} ${BASE_URL}${path}`);
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(15000),
  });

  if (res.status === 401 && !retried) {
    addLog('401', 'التوكن مرفوض، إعادة تسجيل الدخول');
    token = null;
    return apiRequest(method, path, body, true);
  }

  const data = await res.json().catch(() => ({}));
  addLog('RESPONSE', `${res.status}`);
  if (!res.ok) {
    const err = new Error(data.error || `خطأ ${res.status}`);
    err.status = res.status;
    err.details = data.details;
    throw err;
  }
  return data;
}

function status() {
  return {
    baseUrl: BASE_URL,
    username: process.env.API_USERNAME,
    hasToken: Boolean(token),
    tokenPreview: token ? token.slice(0, 12) + '…' + token.slice(-6) : null,
    secondsLeft: token ? Math.max(0, Math.round((tokenExpiresAt - Date.now()) / 1000)) : 0,
    log,
  };
}

function resetToken() {
  token = null;
  tokenExpiresAt = 0;
  addLog('RESET', 'تم حذف التوكن المحفوظ');
}

module.exports = { apiRequest, login, status, resetToken };
