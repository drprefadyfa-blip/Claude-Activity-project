// =====================================================
// المنصة (ب): خادم يعرض واجهة index.html
// ويتصل بالمنصة (أ) من الخادم (Server to Server)
// فلا يظهر التوكن أو كلمة المرور في المتصفح
// =====================================================
require('../lib/env').loadEnv();
const http = require('http');
const path = require('path');
const api = require('./apiClient');
const { sendJson, readJson, serveStatic } = require('../lib/http-utils');

const PORT = Number(process.env.B_PORT || 4000);
const PUBLIC_DIR = path.join(__dirname, 'public');

function sendError(res, e) {
  const refused = e.cause && (e.cause.code === 'ECONNREFUSED' || e.cause.code === 'ENOTFOUND');
  const timeout = e.name === 'TimeoutError';
  const msg = refused
    ? 'تعذر الوصول إلى المنصة (أ). تأكد أنها تعمل وأن الرابط والمنفذ صحيحان.'
    : timeout ? 'انتهت مهلة الاتصال بالمنصة (أ).' : e.message;
  sendJson(res, e.status || (timeout ? 504 : 502), { error: msg, details: e.details });
}

const server = http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];
  try {
    // حالة الربط وسجل الخطوات
    if (req.method === 'GET' && url === '/bridge/status') return sendJson(res, 200, api.status());

    // اختبار الاتصال: تسجيل دخول جديد
    if (req.method === 'POST' && url === '/bridge/login') {
      api.resetToken();
      await api.login();
      return sendJson(res, 200, { ok: true, ...api.status() });
    }

    // حذف التوكن (لتجربة التجديد التلقائي)
    if (req.method === 'POST' && url === '/bridge/reset') {
      api.resetToken();
      return sendJson(res, 200, { ok: true });
    }

    // استلام البيانات من المنصة (أ)
    if (req.method === 'GET' && url === '/bridge/orders') {
      return sendJson(res, 200, await api.apiRequest('GET', '/api/orders'));
    }

    // إرسال البيانات إلى المنصة (أ)
    if (req.method === 'POST' && url === '/bridge/orders') {
      const body = await readJson(req);
      return sendJson(res, 201, await api.apiRequest('POST', '/api/orders', body));
    }

    // الواجهة
    if (req.method === 'GET' && serveStatic(req, res, PUBLIC_DIR)) return;

    sendJson(res, 404, { error: 'المسار غير موجود' });
  } catch (e) {
    sendError(res, e);
  }
});

server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(`[B] ERROR: port ${PORT} is already in use. Close other windows running the project, or change B_PORT in .env`);
  else console.error('[B] ERROR:', e.message);
});

server.listen(PORT, () => {
  console.log(`[B] Platform B (web UI) running on http://localhost:${PORT}`);
});

module.exports = server;
