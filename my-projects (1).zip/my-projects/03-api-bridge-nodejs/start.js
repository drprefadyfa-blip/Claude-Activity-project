// =====================================================
// Run both platforms in ONE window:  node start.js
// تشغيل المنصتين معاً في نافذة واحدة
// =====================================================
const major = Number(process.versions.node.split('.')[0]);
if (major < 18) {
  console.error(`\nERROR: Node.js ${process.versions.node} is too old. Install Node.js 18 or newer (LTS) from https://nodejs.org\n`);
  process.exit(1);
}

process.on('uncaughtException', e => console.error('\nERROR:', e && e.stack ? e.stack : e));

require('./lib/env').loadEnv();
const { exec } = require('child_process');

const A_PORT = Number(process.env.A_PORT || 3000);
const B_PORT = Number(process.env.B_PORT || 4000);
const UI_URL = `http://localhost:${B_PORT}`;

console.log('');
console.log('Starting... / جارٍ التشغيل');
require('./platform-a/server.js');
require('./platform-b/server.js');

// تأكد أن المنصتين تعملان فعلاً، ثم افتح المتصفح
async function ready(url) {
  for (let i = 0; i < 20; i++) {
    try { const r = await fetch(url); if (r.ok) return true; } catch {}
    await new Promise(r => setTimeout(r, 250));
  }
  return false;
}

(async () => {
  const a = await ready(`http://127.0.0.1:${A_PORT}/health`);
  const b = await ready(`http://127.0.0.1:${B_PORT}/bridge/status`);
  console.log('');
  if (a && b) {
    console.log('==================================================');
    console.log('  READY  /  جاهز');
    console.log(`  Open in your browser:  ${UI_URL}`);
    console.log(`  (or  http://127.0.0.1:${B_PORT} )`);
    console.log('');
    console.log('  KEEP THIS WINDOW OPEN while testing.');
    console.log('  Press Ctrl + C to stop.');
    console.log('==================================================');
    if (!process.env.NO_BROWSER) {
      const cmd = process.platform === 'win32' ? `start "" "${UI_URL}"`
        : process.platform === 'darwin' ? `open "${UI_URL}"` : `xdg-open "${UI_URL}"`;
      exec(cmd, () => {});
    }
  } else {
    console.log('==================================================');
    console.log('  NOT READY. Read the ERROR lines above.');
    console.log(`  Platform A (port ${A_PORT}): ${a ? 'OK' : 'FAILED'}`);
    console.log(`  Platform B (port ${B_PORT}): ${b ? 'OK' : 'FAILED'}`);
    console.log('==================================================');
  }
})();
