// اختبار سريع للربط: شغّل المشروع أولاً (npm start) ثم في نافذة أخرى: npm test
require('./lib/env').loadEnv();
const A = `http://localhost:${process.env.A_PORT || 3000}`;
const B = `http://localhost:${process.env.B_PORT || 4000}`;

let passed = 0, failed = 0;
function check(name, cond, info = '') {
  if (cond) { passed++; console.log('✔', name); }
  else { failed++; console.log('✘', name, info); }
}
const j = async (url, opt = {}) => {
  const r = await fetch(url, { ...opt, headers: { 'Content-Type': 'application/json', ...(opt.headers || {}) } });
  return { status: r.status, body: await r.json().catch(() => ({})) };
};

(async () => {
  try {
    // المنصة (أ) مباشرة
    let r = await j(`${A}/api/orders`);
    check('المنصة (أ) ترفض الطلب بدون توكن (401)', r.status === 401, r.status);

    r = await j(`${A}/auth/login`, { method: 'POST', body: JSON.stringify({ username: process.env.API_USERNAME, password: 'wrong' }) });
    check('المنصة (أ) ترفض كلمة مرور خاطئة (401)', r.status === 401, r.status);

    r = await j(`${A}/auth/login`, { method: 'POST', body: JSON.stringify({ username: process.env.API_USERNAME, password: process.env.API_PASSWORD }) });
    check('تسجيل الدخول يعيد توكن', r.status === 200 && !!r.body.token, r.status);
    const token = r.body.token;

    r = await j(`${A}/api/orders`, { headers: { Authorization: 'Bearer ' + token } });
    check('جلب البيانات بالتوكن (200)', r.status === 200 && Array.isArray(r.body.data), r.status);

    r = await j(`${A}/api/orders`, { headers: { Authorization: 'Bearer ' + token + 'x' } });
    check('توكن معدّل يُرفض (401)', r.status === 401, r.status);

    // عبر المنصة (ب)
    r = await j(`${B}/bridge/orders`, { method: 'POST', body: JSON.stringify({ customer: 'اختبار', item: 'خدمة', amount: 1000 }) });
    check('المنصة (ب) ترسل بيانات إلى (أ) (201)', r.status === 201 && r.body.data && r.body.data.id, r.status);

    r = await j(`${B}/bridge/orders`, { method: 'POST', body: JSON.stringify({ customer: '' }) });
    check('بيانات ناقصة تُرفض (422)', r.status === 422, r.status);

    await j(`${B}/bridge/reset`, { method: 'POST' });
    r = await j(`${B}/bridge/orders`);
    check('المنصة (ب) تجدد التوكن تلقائياً وتستلم البيانات', r.status === 200 && r.body.data.some(o => o.customer === 'اختبار'), r.status);
  } catch (e) {
    failed++;
    console.log('✘ تعذر الاتصال. هل شغّلت المشروع بـ npm start؟', e.message);
  }
  console.log(`\nالنتيجة: ${passed} ناجح، ${failed} فاشل`);
  process.exit(failed ? 1 : 0);
})();
