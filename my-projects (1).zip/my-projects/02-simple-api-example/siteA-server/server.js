// الموقع (أ): الخادم الذي يستقبل البيانات ويحفظها ويرسلها عند الطلب
// التشغيل: node server.js   (لا يحتاج تثبيت أي مكتبة)

const http = require('http');

const PORT = process.env.PORT || 3000;
const API_TOKEN = process.env.API_TOKEN || 'my-secret-token-123'; // غيّره إلى توكن خاص بك

const messages = []; // البيانات تُحفظ هنا مؤقتاً (تُمسح عند إعادة التشغيل)

function send(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*', // يسمح للموقع (ب) بالاتصال من نطاق آخر
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  });
  res.end(JSON.stringify(data));
}

http.createServer((req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});

  // التحقق من التوكن
  const auth = req.headers['authorization'] || '';
  if (auth !== 'Bearer ' + API_TOKEN) {
    return send(res, 401, { error: 'توكن غير صحيح أو مفقود' });
  }

  // استلام البيانات: POST /api/messages
  if (req.method === 'POST' && req.url === '/api/messages') {
    let body = '';
    req.on('data', chunk => (body += chunk));
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        if (!data.name || !data.text) {
          return send(res, 400, { error: 'الحقلان name و text مطلوبان' });
        }
        const item = { id: messages.length + 1, name: data.name, text: data.text, date: new Date().toISOString() };
        messages.push(item);
        send(res, 201, { ok: true, saved: item });
      } catch {
        send(res, 400, { error: 'صيغة JSON غير صحيحة' });
      }
    });
    return;
  }

  // إرسال البيانات: GET /api/messages
  if (req.method === 'GET' && req.url === '/api/messages') {
    return send(res, 200, { count: messages.length, messages });
  }

  send(res, 404, { error: 'المسار غير موجود' });
}).listen(PORT, () => console.log('الموقع (أ) يعمل على http://localhost:' + PORT));
